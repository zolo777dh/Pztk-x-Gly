local _,ns=...
local W=ns.Widgets
local C=W.colors
local L=ns.L
local kit=ns.UIKit

local SPELLS={
    DEATHKNIGHT={{48707,60},{48792,120},{51052,240},{49028,120,250},{55233,90,250},{51271,45,251},{42650,90,252}},
    DEMONHUNTER={{198589,60,577,1480},{191427,120,577},{196718,300}},
    DRUID={{22812,60},{106898,120},{61336,180,103,104},{194223,180,102},{106951,180,103},{102558,180,104},{22842,36,104},{204066,60,104},
        {102342,90,105},{740,180,105}},
    EVOKER={{363916,90},{374227,120},{374968,120},{375087,120,1467},{363534,240,1468},{357170,60,1468},{403631,120,1473}},
    HUNTER={{186265,180},{264735,90},{19574,90,253},{288613,120,254},{1250646,90,255}},
    MAGE={{45438,240},{342245,60},{66,300},{365350,90,62},{55342,120,62},{235450,30,62},{190319,120,63},{235313,30,63},{11426,30,64}},
    MONK={{116841,30},{115203,360,269,270},{132578,120,268},{123904,120,269},{122470,90,269},{116849,120,270}},
    PALADIN={{1022,300},{6940,120},{31884,120},{1044,25},{642,300,65,70},{498,60,65,70},{31821,180,65},{31850,90,66}},
    PRIEST={{19236,90},{10060,120},{33206,180,256},{62618,180,256},{47788,180,257},{200183,120,257},{228260,120,258},{47585,120,258},{15286,120,258}},
    ROGUE={{31224,120},{5277,120},{1966,15},{185311,30},{1856,120},{360194,120,259},{121471,90,261}},
    SHAMAN={{108271,120},{198103,180},{192077,120},{114050,180,262},{191634,60,262},{114051,180,263},{98008,180,264}},
    WARLOCK={{104773,180},{108416,60},{205180,120,265},{265187,60,266},{1122,120,267}},
    WARRIOR={{97462,180},{23920,25},{118038,120,71},{1719,90,72},{184364,120,72}},
}
local KICKS={
    DEATHKNIGHT={{47528,15}},DEMONHUNTER={{183752,15}},DRUID={{106839,15,103,104},{78675,60,102}},EVOKER={{351338,20,1467,1473}},
    HUNTER={{147362,24,253,254},{187707,15,255}},MAGE={{2139,25}},MONK={{116705,15,268,269}},PALADIN={{96231,15,66,70}},PRIEST={{15487,30,258}},
    ROGUE={{1766,15}},SHAMAN={{57994,12}},WARLOCK={{19647,24,265,267},{89766,30,266}},WARRIOR={{6552,15},{386071,90,73}},
}
local STOPS={
    DEATHKNIGHT={{207167,60},{108199,90,250}},DEMONHUNTER={{179057,45},{207684,120},{202138,60,581}},
    DRUID={{99,30},{102793,60},{132469,30}},HUNTER={{109248,45},{19577,60}},MONK={{119381,60}},PALADIN={{853,45},{115750,90}},
    PRIEST={{8122,40}},ROGUE={{2094,120}},SHAMAN={{192058,60}},WARLOCK={{30283,60}},WARRIOR={{46968,40},{5246,90}},
}
local KIND={}
for kind,lists in pairs({kick=KICKS,cc=STOPS})do
    for class,list in pairs(lists)do for _,s in ipairs(list)do table.insert(SPELLS[class],s);KIND[s[1]]=kind end end
end
for _,id in ipairs({119381,179057,30283,192058,46968,109248,853,19577})do KIND[id]="stun"end
for _,id in ipairs({106898,192077,1044,116841,374968})do KIND[id]="move"end
local POTIONS={1236616,1236994,1236998,1239479,1295132}
local POTION=POTIONS[1]
KIND[POTION]="potion"
local LISTS={"kick","stun","cc","move","potion"}
local FIELD={["kick"]="kicks",["stun"]="stuns",["cc"]="cc",["move"]="moves",["potion"]="potions"}
ns.PartyCooldownLists=LISTS
ns.PartyCooldownKind=function(id)return KIND[id]end
ns.PartyCooldownSpells=SPELLS
local byID={}
for class,list in pairs(SPELLS)do for order,s in ipairs(list)do byID[s[1]]={class=class,cd=s[2],order=order,specs=#s>2 and{select(3,unpack(s))}or nil}end end
local RACIAL={NightElf={{58984,120}},Dwarf={{20594,120}}}
for race,list in pairs(RACIAL)do for i,s in ipairs(list)do byID[s[1]]={race=race,cd=s[2],order=900+i}end end
byID[POTION]={cd=300,order=950,anyone=true}
ns.PartyCooldownPotion=POTION

local TALENT_CD={
    [49028]={{377637,add=-30}},[48707]={{205727,add=-20},{457574,add=20}},[51052]={{374383,add=-60}},
    [196718]={{389783,add=-120}},
    [194223]={{390378,add=-60},{468743,add=-60}},[102560]={{390378,add=-60},{468743,add=-60}},
    [106951]={{391174,add=-60},{391548,add=-30}},[102543]={{391174,add=-60},{391548,add=-30}},
    [22812]={{spec=104,add=-15},{203965,pct=-12}},[61336]={{203965,pct=-12}},[102342]={{382552,add=-20}},
    [363534]={{381922,add=-60}},[403631]={{412713,pct=-10}},[363916]={{412713,pct=-10}},[357170]={{376204,add=-10}},[374227]={{412713,pct=-10}},
    [19574]={{231548,add=-60}},[288613]={{260404,add=-30}},[186265]={{266921,add=-15},{1258485,add=-30}},
    [190319]={{1254194,add=-60}},[45438]={{382424,add=-30},{1265517,add=-30},{1244110,add=-30}},[414658]={{382424,add=-30},{1265517,add=-30},{1244110,add=-30}},
    [342245]={{342249,add=-5},{1255166,add=-10}},[55342]={{1244025,add=-30}},
    [132578]={{450989,add=-25}},[123904]={{392986,add=-30}},[115203]={{spec=269,add=-240},{spec=270,add=-240},{388813,add=-30}},[116849]={{202424,add=-45}},
    [31884]={{spec=70,add=-60},{1241511,add=-15},{204074,pct=-50}},[231895]={{1241511,add=-15}},[216331]={{1241511,add=-15}},
    [642]={{114154,pct=-30},{378425,pct=-15}},[498]={{spec=70,add=30},{114154,pct=-30}},[31850]={{114154,pct=-30}},
    [6940]={{384820,add=-60},{384820,spec=65,add=45}},[1022]={{384909,add=-60},{378425,pct=-15}},[31821]={{392911,add=-30}},
    [19236]={{238100,add=-20}},[47585]={{288733,add=-30}},
    [114050]={{462440,add=-60}},[114051]={{384444,add=-60}},[108271]={{381647,add=-30}},
    [1122]={{1280483,add=-30}},[104773]={{386659,add=-45}},[108416]={{386686,add=-15}},
    [118038]={{391271,pct=-10}},[184364]={{391271,pct=-10}},[23920]={{spec=73,add=-5},{391271,pct=-10}},
    [191634]={{468571,add=-15},{454026,add=-15}},[106898]={{288826,add=-60}},[192077]={{462791,add=-30}},
    [66]={{110959,add=-180},{210476,add=-60}},
    [47528]={{378848,add=-3}},[78675]={{202918,add=-15}},[351338]={{412713,pct=-10}},[2139]={{382297,add=-5}},[57994]={{spec=264,add=18}},
    [6552]={{391271,pct=-10}},
    [119381]={{344359,add=-5}},[30283]={{1270255,add=-15}},[192058]={{381867,add=-5},{265046,add=-10},{445027,add=-5}},
    [46968]={{275339,add=-15},{440992,add=-5}},[19577]={{459507,add=-20}},[115750]={{469325,add=-15}},
    [8122]={{196704,add=-10}},[5246]={{424742,add=-15}},[207684]={{320418,add=-30},{389718,pct=-15}},[202138]={{389718,pct=-15}},
    [132469]={{400140,add=-5}},[2094]={{200733,pct=-50},{256165,pct=-25},{441415,pct=-10}},[374968]={{412713,pct=-10}},[204066]={{429539,add=-20}},[1250646]={{1251790,add=-15}},
}
local LIKELY={
    [250]={[49028]=90,[48707]=40,[47528]=12},[251]={[48707]=40,[47528]=12},[252]={[48707]=40,[47528]=12},
    [577]={[198589]=60,[196718]=180},[581]={[196718]=180},[1480]={[198589]=60,[196718]=180},
    [102]={[194223]=120,[78675]=45},[103]={[106951]=90},[104]={[22812]=34,[22842]=20,[204066]=40,[61336]=137,[106898]=60},[105]={[102342]=70},
    [253]={[19574]=30,[186265]=120},[254]={[186265]=120},[255]={[186265]=120},
    [62]={[45438]=150,[342245]=55,[66]=60,[55342]=60,[2139]=20},[63]={[190319]=60,[45438]=150,[342245]=50,[66]=60,[2139]=20},[64]={[45438]=120,[342245]=50,[66]=60,[2139]=20},
    [269]={[115203]=90},[270]={[116849]=75,[115203]=90},
    [65]={[1022]=240,[31884]=90,[642]=210,[498]=42,[31821]=150},[66]={[31884]=60,[31850]=63,[6940]=60},[70]={[31884]=60,[642]=210,[498]=63,[6940]=60},
    [257]={[19236]=70},[258]={[19236]=70},
    [262]={[114050]=120,[108271]=90},[263]={[114051]=120,[108271]=90},[264]={[108271]=90},
    [265]={[108416]=45},[266]={[108416]=45},[267]={[108416]=45},
    [71]={[118038]=108,[23920]=23,[46968]=25},[72]={[184364]=108,[23920]=23,[46968]=25},[73]={[23920]=23,[46968]=25},
}
local SPEND={WARRIOR={talent=152278,power=1,sec=1,per={[72]=20},spells={[72]={1719}}},
    DEATHKNIGHT={talent=205723,power=6,sec=2,per={[250]=10},spells={[250]={55233}}},
    DRUID={talent=393414,power=1,sec=1,per={[104]=25},spells={[104]={102558}}}}
local WANTED={}
for _,mods in pairs(TALENT_CD)do for _,x in ipairs(mods)do if x[1]then WANTED[x[1]]=true end end end
for _,sp in pairs(SPEND)do WANTED[sp.talent]=true end
local ALIAS={[1236994]=POTION,[1236998]=POTION,[1239479]=POTION,[1295132]=POTION,[77761]=106898,[77764]=106898,[110959]=66,[204018]=1022,[231895]=31884,[216331]=31884,[389539]=31884,[442204]=403631,
    [102560]=194223,[102543]=106951,[414658]=45438,
    [389813]=207684,[389807]=202138,[474421]=19577,[119910]=19647,[132409]=19647,[1276467]=19647,[119914]=89766}
local DYNAMIC={
    [49028]=true,[55233]=true,[51271]=true,[42650]=true,   -- DRW (Bone Shield), VB (Red Thirst), PoF (Icecap), Army (Death Coil)
    [106951]=true,[102558]=true,[19574]=true,[288613]=true, -- Feral Berserk (combo points), Guardian Incarnation (rage), Bestial Wrath (Barbed Shot), Trueshot (focus)
    [190319]=true,[123904]=true,[1719]=true,                -- Combustion (crits), Xuen (Combo Strikes), Recklessness (Anger Management)
    [31884]={66},                                           -- Protection Righteous Protector (Holy Power)
    [853]=true,                                             -- Hammer of Justice (Fist of Justice, Holy Power)
}
local function Dynamic(id,spec)
    local d=DYNAMIC[id];if d==true then return true end
    if d then for _,s in ipairs(d)do if s==spec then return true end end end
    return false
end
ns.PartyCooldownDynamic=Dynamic
ns.PartyCooldownTalentMods=TALENT_CD
local defaults={enabled=false,mode="frames",side="RIGHT",size=26,self=true,raidGroup=true,hideReady=false,names=false,sensors=true,kicks=true,cc=true,stuns=true,moves=true,potions=true,
    share=true,cdm=true,detect=true,loadWhere="all",loadSolo=true,perRow=0,size2=20,highlight=true,tooltip=false,order={},pos={x=-420,y=120},
    anchors={kick={x=-420,y=-60,style="bars",size=22,width=200,dir="RIGHT",grow="DOWN",perRow=1,rows=5,names=true,hideReady=false,texture="",mark=true,dark=false,hideInRaid=false},
        cc={x=-420,y=-220,style="icons",size=30,width=180,dir="RIGHT",grow="DOWN",perRow=8,rows=2,names=false,hideReady=false,texture="",hideInRaid=false},
        stun={x=-420,y=-300,style="icons",size=30,width=180,dir="RIGHT",grow="DOWN",perRow=8,rows=2,names=false,hideReady=false,texture="",hideInRaid=false},
        move={x=-420,y=-380,style="icons",size=30,width=180,dir="RIGHT",grow="DOWN",perRow=8,rows=1,names=false,hideReady=false,texture="",hideInRaid=false},
        potion={x=-640,y=-60,style="bars",size=20,width=170,dir="RIGHT",grow="DOWN",perRow=1,rows=5,names=true,hideReady=false,texture="",hideInRaid=false}},
    learned={},disabled={},specOff={},custom={},talentSpells={}}
function ns.PartyCooldownConfig()
    local store=ns.Store();store.partycds=store.partycds or{}
    local c=store.partycds
    for k,v in pairs(defaults)do if c[k]==nil then c[k]=type(v)=="table"and ns.Clone(v)or v end end
    for key,a in pairs(defaults.anchors)do
        c.anchors[key]=type(c.anchors[key])=="table"and c.anchors[key]or{}
        if c.anchors[key].self==nil then c.anchors[key].self=c.self~=false end
        for k,v in pairs(a)do if c.anchors[key][k]==nil then c.anchors[key][k]=v end end
    end
    if c.loadWorld==false and c.loadWhere=="all"then c.loadWhere="instances"end;c.loadWorld=nil
    if(c.layout or 0)<2 then c.layout=2;c.mode="frames";c.hideReady=false;c.names=false end
    if(c.aliasMigrated or 0)<2 then c.aliasMigrated=2
        for _,ids in pairs(c.custom)do for id in pairs(ids)do local base=ALIAS[tonumber(id)]if base then ids[id]=nil end end end
        local function move(t)
            local found={};for id,v in pairs(t)do local base=ALIAS[tonumber(id)];if base then found[#found+1]={id,base,v}end end
            for _,x in ipairs(found)do t[x[1]]=nil;if t[x[2]]==nil then t[x[2]]=x[3]end end
        end
        move(c.disabled);for _,off in pairs(c.specOff)do if type(off)=="table"then move(off)end end
        for _,t in pairs(c.learned)do if type(t)=="table"then move(t)end end
        for spec,list in pairs(c.order)do if type(list)=="table"then
            local out,seen={},{};for _,id in ipairs(list)do id=ALIAS[id]or id;if not seen[id]then seen[id]=true;out[#out+1]=id end end;c.order[spec]=out
        end end
    end
    if(c.learnedVersion or 0)<1 then c.learnedVersion=1
        for _,t in pairs(c.learned)do if type(t)=="table"then
            local bad={};for id,v in pairs(t)do local info=byID[tonumber(id)]
                if type(v)~="number"or v<=3 or(info and(info.cd or 0)>0 and v<info.cd*0.25)then bad[#bad+1]=id end
            end
            for _,id in ipairs(bad)do t[id]=nil end
        end end
    end
    return c
end
function ns.PartyName(name)
    local shown=ns.DisplayName and ns.DisplayName(name)or name
    return type(shown)=="string"and(shown:match("^([^%-]+)")or shown)or tostring(name)
end
local members={}
ns.PartyCooldownMembers=members
local perf={}
local function Clock()return debugprofilestop and debugprofilestop()or(GetTime()*1000)end
local function Timed(key,fn,...)
    local t=Clock();local a,b,c=fn(...)
    local p=perf[key]or{ms=0,n=0,max=0};perf[key]=p;local d=Clock()-t
    p.ms=p.ms+d;p.n=p.n+1;if d>p.max then p.max=d end
    return a,b,c
end
ns.PartyCooldownTimed=Timed
function ns.PartyCooldownPerf(reset)if reset then perf={}end;return perf end
local function Register(id,class,order)
    if byID[id]then return byID[id]end
    byID[id]={class=class,cd=0,order=order,added=true};return byID[id]
end
local function LoadCustom()
    for class,ids in pairs(ns.PartyCooldownConfig().custom)do for id in pairs(ids)do Register(tonumber(id)or id,class,900+(tonumber(id)or 0)%1000)end end
end
function ns.PartyCooldownSpellInfo(id)return byID[id]end
function ns.PartyCooldownClassSpells(class)
    local out={};for _,s in ipairs(SPELLS[class]or{})do out[#out+1]=s[1]end
    local extra={};for id in pairs(ns.PartyCooldownConfig().custom[class]or{})do id=tonumber(id);if id and not byID[id]then Register(id,class,900+id%1000)end;if id and byID[id].added and byID[id].class==class then extra[#extra+1]=id end end
    for id,info in pairs(byID)do if info.detected and info.class==class then extra[#extra+1]=id end end
    table.sort(extra);for _,id in ipairs(extra)do out[#out+1]=id end
    return out
end
function ns.AddPartyCooldownSpell(class,id)
    id=tonumber(id);if not SPELLS[class]then return nil,"Choose a class"end
    if not id or id<1 or id~=math.floor(id)then return nil,"Enter a spell ID"end
    if ALIAS[id]or byID[id]and not byID[id].added then return nil,"This spell is already in the list"end
    if byID[id]and byID[id].sent then byID[id].class=class end
    if byID[id]and byID[id].class~=class then return nil,"This spell is already added for another class"end
    local cfg=ns.PartyCooldownConfig();cfg.custom[class]=cfg.custom[class]or{};cfg.custom[class][id]=true;cfg.disabled[id]=nil
    Register(id,class,900+id%1000).added=true;ns.RebuildPartyCooldownSensors();ns.DrawPartyCooldowns();return true
end
function ns.RemovePartyCooldownSpell(class,id)
    local cfg=ns.PartyCooldownConfig();local ids=cfg.custom[class];if not ids or not ids[id]then return nil,"Only added spells can be removed"end
    ids[id]=nil
    local used=false;for _,other in pairs(cfg.custom)do if other[id]then used=true end end
    if byID[id]and byID[id].added and not used then if byID[id].sent then byID[id].added=nil else byID[id]=nil end end
    ns.RebuildPartyCooldownSensors();ns.DrawPartyCooldowns();return true
end
function ns.SetPartyCooldownTracked(id,on,spec)
    local cfg=ns.PartyCooldownConfig()
    if spec then
        if on and cfg.disabled[id]then
            cfg.disabled[id]=nil;local info=byID[id]
            for _,other in ipairs(info and ns.ClassSpecs and ns.ClassSpecs[info.class]or{})do if other~=spec then cfg.specOff[other]=cfg.specOff[other]or{};cfg.specOff[other][id]=true end end
        end
        cfg.specOff[spec]=cfg.specOff[spec]or{};cfg.specOff[spec][id]=(not on)or nil
    else cfg.disabled[id]=(not on)or nil end
    ns.RebuildPartyCooldownSensors();ns.DrawPartyCooldowns();return true
end
function ns.PartyCooldownTracked(id,spec)
    local cfg=ns.PartyCooldownConfig()
    if byID[id]==nil or cfg.disabled[id]then return false end
    return not(spec and cfg.specOff[spec]and cfg.specOff[spec][id])
end

local function ForSpec(info,spec,candidates)
    if not info then return false end
    if not info.specs then return true end
    for _,s in ipairs(info.specs)do
        if s==spec then return true end
        if not spec and candidates then for _,c in ipairs(candidates)do if c==s then return true end end end
    end
    return false
end
local function Known(id)
    local known=C_SpellBook and(C_SpellBook.IsSpellKnownOrInSpellBook or C_SpellBook.IsSpellKnown)or IsPlayerSpell
    if not known then return false end
    local ok,v=pcall(known,id);if ok and ns.Plain(v,"boolean")and v then return true end
    local bank=C_SpellBook and Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Pet
    if bank~=nil then local ok2,pet=pcall(known,id,bank);return ok2 and ns.Plain(pet,"boolean")and pet or false end
    return false
end
local PET_KICK={[19647]=true,[89766]=true}
local FACTION={[2825]="Horde",[32182]="Alliance"}
local TANKS={[66]=1,[73]=1,[104]=1,[250]=1,[268]=1,[581]=1}
local HEALERS={[65]=1,[105]=1,[256]=1,[257]=1,[264]=1,[270]=1,[1468]=1}
function ns.RoleSpecs(class,role)
    local out={}
    for _,spec in ipairs(ns.ClassSpecs and ns.ClassSpecs[class]or{})do
        local r=TANKS[spec]and"TANK"or HEALERS[spec]and"HEALER"or"DAMAGER"
        if r==role then out[#out+1]=spec end
    end
    return #out>0 and out or nil
end
local function Sorter(spec)
    local list=spec and ns.PartyCooldownConfig().order[spec];local pos={}
    for i,id in ipairs(type(list)=="table"and list or{})do pos[id]=i end
    return function(a,b)
        local pa,pb=pos[a]or 1000+byID[a].order,pos[b]or 1000+byID[b].order
        if pa~=pb then return pa<pb end;return a<b
    end
end
function ns.PartyCooldownSpecSpells(class,spec)
    local out={}
    for _,id in ipairs(ns.PartyCooldownClassSpells(class))do if ForSpec(byID[id],spec)then out[#out+1]=id end end
    table.sort(out,Sorter(spec))
    return out
end
function ns.MovePartyCooldown(class,spec,id,step)
    local ids=ns.PartyCooldownSpecSpells(class,spec);local at
    for i,x in ipairs(ids)do if x==id then at=i end end
    local to=at and at+step;if not to or to<1 or to>#ids then return false end
    ids[at],ids[to]=ids[to],ids[at];ns.PartyCooldownConfig().order[spec]=ids;ns.DrawPartyCooldowns();return true
end
local Dropped -- a class spell the member's own list no longer has; defined with the timers
function ns.PartyCooldownList(member,kind)
    local out,seen={},{}
    local cfg=ns.PartyCooldownConfig()
    local function add(id)
        local info=byID[id];local custom=cfg.custom[member.class]
        -- Observing an item/unknown spell on one member does not give it to their class.
        if info and(info.detected or info.sent)and not(custom and(custom[id]or custom[tostring(id)]))
            and not(member.known and member.known[id])and not(member.used and member.used[id])then return end
        if not seen[id]and(not kind or(KIND[id]or"defensive")==kind)and(not KIND[id]or cfg[FIELD[KIND[id]]]~=false)and ns.PartyCooldownTracked(id,member.spec)and(member.me or not Dynamic(id,member.spec))and not(member.talented and member.talented[id]==false and not(member.known and member.known[id]))then seen[id]=true;out[#out+1]=id end
    end
    if member.known then for id in pairs(member.known)do add(id)end
    elseif member.class and SPELLS[member.class]then
        local faction=member.faction
        for _,id in ipairs(ns.PartyCooldownClassSpells(member.class))do
            local info=byID[id]
            local unread=not member.me and not member.talented and ns.PartyCooldownConfig().talentSpells[id]
            if ForSpec(info,member.spec,member.roleSpecs)and not unread and not(FACTION[id]and faction and FACTION[id]~=faction)and(not member.me or info.added or info.detected or Known(id))then add(id)end
        end
    end
    for _,s in ipairs(member.race and RACIAL[member.race]or{})do if not member.me or Known(s[1])then add(s[1])end end
    add(POTION)
    for id in pairs(member.used or{})do local info=byID[id]
        if not(info and member.spec and not ForSpec(info,member.spec))and not Dropped(member,id)then add(id)end
    end
    table.sort(out,Sorter(member.spec))
    return out
end
local function BaseCooldown(id)
    local get=(C_Spell and C_Spell.GetSpellBaseCooldown)or GetSpellBaseCooldown
    if get then local ok,ms=pcall(get,id);if ok and ns.Plain(ms,"number")and ms>1500 then return ms/1000 end end
    return byID[id]and byID[id].cd or 0
end
local function WithTalents(m,id,base)
    local mods=TALENT_CD[id];if not mods then return base end
    local ranks=m and m.ranks
    local cd,mul=base,1
    for _,x in ipairs(mods)do
        local rank=0
        if x[1]then rank=ranks and ranks[x[1]]or 0 else rank=1 end
        if x.spec and x.spec~=(m and m.spec)then rank=0 end
        if rank>0 then cd=cd+(x.add or 0)*rank;mul=mul*(1+(x.pct or 0)*rank/100)end
    end
    return math.max(5,math.floor(cd*mul+0.5))
end
ns.PartyCooldownWithTalents=WithTalents
function ns.PartyCooldownLength(member,id)
    local sent=member and member.cds and member.cds[id];if sent then return sent end
    if member and member.me then
        local learned=ns.PartyCooldownConfig().learned[ns.PartyCooldownLearnKey(member)]
        if learned and learned[id]then return learned[id]end
    end
    local likely=member and not member.me and not member.ranks and member.spec and LIKELY[member.spec]
    if likely and likely[id]then return likely[id]end
    return WithTalents(member,id,BaseCooldown(id))
end
function ns.PartyCooldownLearnKey(member)
    local key=tostring(member and member.spec or ns.Spec()or 0)
    local ranks=member and member.ranks;if not ranks then return key end
    local ids={};for id,r in pairs(ranks)do if r>0 then ids[#ids+1]=id..":"..r end end;table.sort(ids)
    return key.."/"..table.concat(ids,",")
end
local function OwnInfo(id)
    local get=C_Spell and C_Spell.GetSpellCooldown;if not get or id==POTION then return nil end
    local ok,info=pcall(get,id);if not ok or not ns.Plain(info,"table")then return nil end
    local read,start,dur,active,gcd=pcall(function()return info.startTime,info.duration,info.isActive,info.isOnGCD end)
    if not read then return nil end
    return start,dur,active,gcd
end
local function OwnCooldown(id)
    local start,dur,active,gcd=OwnInfo(id)
    if ns.Plain(gcd,"boolean")and gcd then return 0,0 end
    if ns.Plain(start,"number")and ns.Plain(dur,"number")then
        if dur>1.5 and start>0 then return start,dur end
        return 0,0
    end
    if ns.Plain(active,"boolean")and not active then return 0,0 end
    return nil
end
ns.PartyCooldownOwn=OwnCooldown
local function OwnHidden(m,id)
    if not(m and m.me)or id==POTION or OwnCooldown(id)then return nil end
    local get=C_Spell and C_Spell.GetSpellCooldownDuration
    if get then local ok,object=pcall(get,id);if ok and object~=nil and object~=false then return object end end
    local start=m.used[id];if start and GetTime()<start+ns.PartyCooldownLength(m,id)then return nil end
    return true
end
ns.PartyCooldownOwnHidden=OwnHidden
local function ObjectZero(object)
    if type(object)~="table"and type(object)~="userdata"then return nil end
    local ok,zero=pcall(function()return object:IsZero()end)
    if ok and ns.Plain(zero,"boolean")then return zero end
end
function ns.PartyCooldownReady(m,id)
    if not m then return false end
    local own=OwnHidden(m,id)
    if own then return ObjectZero(own)==true end
    return ns.PartyCooldownLeft(m,id)<=0
end
local function OwnGrey(icon,object)
    local zero=ObjectZero(object)
    if zero~=nil or type(object)~="table"and type(object)~="userdata"then
        if icon.ownGrey then icon.ownGrey:Hide()end
        icon.tex:SetDesaturated(zero==false);return zero~=nil
    end
    icon.tex:SetDesaturated(false)
    local g=icon.ownGrey
    if not g then
        g=icon:CreateTexture(nil,"ARTWORK",nil,7);g:SetAllPoints(icon.tex);g:SetTexCoord(0.07,0.93,0.07,0.93)
        if icon.tex.GetTexCoord then pcall(function()g:SetTexCoord(icon.tex:GetTexCoord())end)end
        pcall(g.SetDesaturated,g,true);icon.ownGrey=g
    end
    g:SetTexture(icon.tex:GetTexture())
    local ok,hidden=pcall(object.IsZero,object)
    if not ok then g:Hide();return false end
    g:Show()
    if g.SetAlphaFromBoolean and pcall(g.SetAlphaFromBoolean,g,hidden,0,1)then return true end
    local eval=C_CurveUtil and C_CurveUtil.EvaluateColorValueFromBoolean
    if eval then local ok2,v=pcall(eval,hidden,0,1);if ok2 and pcall(g.SetAlpha,g,v)then return true end end
    g:Hide();return false
end
ns.PartyCooldownOwnGrey=OwnGrey
local function DrawOwnHidden(cd,object)
    if type(object)~="table"and type(object)~="userdata"then cd:Clear();return false end
    if cd.SetCooldownFromDurationObject then return pcall(cd.SetCooldownFromDurationObject,cd,object)end
    cd:Clear();return false
end
local SURE={cast=true,sensor=true,named=true}
local function Hidden(m,id)
    local t=m.hiddenCd and m.hiddenCd[id]
    if not t then return nil end
    local now=GetTime()
    if t.slot and not(InCombatLockdown and InCombatLockdown())then
        if not t.over then t.over=now+t.cd end
        local plain=true;for k=1,2 do local sl=t.slot[k];if not sl or not ns.Plain(sl.code,"number")then plain=false end end
        if plain and ns.PartyCooldownHiddenLeft(t,now)<=0 then m.hiddenCd[id]=nil;return nil end
    end
    if t.over and now>=t.over then m.hiddenCd[id]=nil;return nil end
    return t
end
function ns.PartyCooldownExact(member,id)
    if not member then return false end
    if member.me then local start=OwnCooldown(id);if start and start>0 then return true end
        local object=OwnHidden(member,id);if object and object~=true then return true end end
    if Hidden(member,id)and not member.used[id]then return false end
    local how=member.how and member.how[id]
    return(member.cds and member.cds[id]and SURE[how]and not(member.cut and member.cut[id]))and true or false
end
local function MarkOf(unit)
    if not(GetRaidTargetIndex and ns.Plain(unit,"string"))then return nil end
    local ok,i=pcall(GetRaidTargetIndex,unit);return ok and ns.Plain(i,"number")and i>0 and i or nil
end
ns.PartyCooldownMarkOf=MarkOf
local HIGHLIGHT=3
Dropped=function(m,id)
    local info=byID[id]
    return m.known and m.listFull and info and info.class and info.class==m.class and not info.detected and not info.added and not m.known[id]or false
end
local function Prune(m,spec)
    for id in pairs(m.used or{})do local info=byID[id]
        if info and spec and not ForSpec(info,spec)then m.used[id]=nil;if m.how then m.how[id]=nil end;if m.hiddenCd then m.hiddenCd[id]=nil end;if m.chg then m.chg[id]=nil end end
    end
    m.face=nil
end
ns.PartyCooldownPrune=Prune
local function OwnCharges(id)
    local get=C_Spell and C_Spell.GetSpellCharges;if not get or id==POTION then return nil end
    local ok,c=pcall(get,id);if not ok or not ns.Plain(c,"table")then return nil end
    local read,cur,max,start,dur=pcall(function()return c.currentCharges,c.maxCharges,c.cooldownStartTime,c.cooldownDuration end)
    if not read or not(ns.Plain(cur,"number")and ns.Plain(max,"number"))or max<2 then return nil end
    return cur,max,ns.Plain(start,"number")and start or nil,ns.Plain(dur,"number")and dur or nil
end
ns.PartyCooldownOwnCharges=OwnCharges
local function MaxCharges(m,id)
    if m.me then local _,max=OwnCharges(id);return max or 1 end
    return m.charges and m.charges[id]or 1
end
local function Recharge(m,id,now)
    local st=m.chg and m.chg[id];if not st then return nil end
    local max,len=MaxCharges(m,id),ns.PartyCooldownLength(m,id)
    while st.next and now>=st.next and st.avail<max do
        st.avail=st.avail+1;st.next=st.avail<max and st.next+len or nil
    end
    if st.avail>=max then st.avail,st.next=max,nil end
    return st
end
function ns.PartyCooldownCharges(m,id)
    if not m then return nil end
    if m.me then
        local cur,max,start,dur=OwnCharges(id);if not cur then return nil end
        return cur,max,(cur<max and start and dur and dur>0)and start or nil,dur
    end
    local max=MaxCharges(m,id);if max<2 then return nil end
    local st=Recharge(m,id,GetTime())
    if not st then return max,max end
    local len=ns.PartyCooldownLength(m,id)
    return st.avail,max,st.next and st.next-len or nil,len
end
local function Started(m,id,at,how,mark)
    local max=not m.me and MaxCharges(m,id)or 1
    if max>1 then
        m.chg=m.chg or{};local st=m.chg[id]or{avail=max};m.chg[id]=st;Recharge(m,id,at)
        st.avail=math.max(0,st.avail-1);if not st.next then st.next=at+ns.PartyCooldownLength(m,id)end
    end
    m.used[id]=at;m.how=m.how or{};m.how[id]=how;if m.cut then m.cut[id]=nil end
    m.marks=m.marks or{};m.marks[id]=mark
    if ns.PartyCooldownConfig().highlight and C_Timer and C_Timer.NewTimer then C_Timer.NewTimer(HIGHLIGHT+0.1,function()ns.DrawPartyCooldowns()end)end
end
function ns.PartyCooldownLeft(member,id)
    if member and member.me then local start,dur=OwnCooldown(id);if start then return start>0 and math.max(0,start+dur-GetTime())or 0 end end
    local start=member and member.used and member.used[id];if not start then return 0 end
    if not member.me and MaxCharges(member,id)>1 then
        local st=Recharge(member,id,GetTime());if not st then return 0 end
        return st.avail>0 and 0 or math.max(0,(st.next or 0)-GetTime())
    end
    return math.max(0,start+ns.PartyCooldownLength(member,id)-GetTime())
end

local function Units()
    local cfg=ns.PartyCooldownConfig();local out={"player"}
    if IsInRaid and IsInRaid()then
        if not cfg.raidGroup or not GetRaidRosterInfo then return out end
        local me=ns.UnitFullName("player");local mine
        for i=1,40 do local name,_,group=GetRaidRosterInfo(i);if name and ns.FullName(name)==me then mine=group end end
        for i=1,40 do local name,_,group=GetRaidRosterInfo(i)
            if name and group==mine and ns.FullName(name)~=me then out[#out+1]="raid"..i end
        end
    elseif IsInGroup and IsInGroup()then
        for i=1,4 do if UnitExists and UnitExists("party"..i)then out[#out+1]="party"..i end end
    end
    return out
end
local function InspectSpec(unit)
    if unit=="player"then return ns.Spec()end
    if not GetInspectSpecialization then return nil end
    local ok,spec=pcall(GetInspectSpecialization,unit)
    return ok and ns.Plain(spec,"number")and spec>0 and spec or nil
end
local order={}
local pendingPCD,ReadPendingPCD={},nil -- group messages from players not in the roster yet
local askAgain=true -- a new member: the others are asked for their cooldowns with the next share
local needSend=true -- your cooldowns go out once per group (again for a new member, a request or a change)
local inspected={} -- talents read by inspecting, by GUID, kept for the session
function ns.PartyCooldownRoster()
    local keep={};order={}
    for _,unit in ipairs(Units())do
        local name=ns.UnitFullName(unit);local class;if UnitClass then class=select(2,UnitClass(unit))end
        if name then
            local guid=UnitGUID and select(2,pcall(UnitGUID,unit));guid=ns.Plain(guid,"string")and guid or nil
            local m=members[name]
            if m and guid and m.guid and m.guid~=guid then m=nil end
            if not m then m={name=name,used={}};if unit~="player"then askAgain=true;needSend=true end
                local seen=guid and inspected[guid];if seen then m.spec,m.talented,m.ranks=seen.spec,seen.talented,seen.ranks end
            end
            members[name]=m;m.guid=guid or m.guid
            m.unit=unit;m.me=unit=="player";m.class=ns.Plain(class,"string")and class or m.class
            m.spec=(m.me and ns.Spec())or m.sentSpec or InspectSpec(unit)or m.spec
            if UnitRace then local ok,_,race=pcall(UnitRace,unit);if ok and ns.Plain(race,"string")then m.race=race end end
            if UnitFactionGroup then local ok,f=pcall(UnitFactionGroup,unit);if ok and ns.Plain(f,"string")then m.faction=f end end
            local role=UnitGroupRolesAssigned and UnitGroupRolesAssigned(unit)
            m.roleSpecs=m.class and ns.Plain(role,"string")and ns.RoleSpecs(m.class,role)or nil
            if not m.spec and m.roleSpecs and #m.roleSpecs==1 then m.spec=m.roleSpecs[1]end
            keep[name]=true;order[#order+1]=name
        end
    end
    for name in pairs(members)do if not keep[name]then members[name]=nil end end
    if next(pendingPCD)and ReadPendingPCD then ReadPendingPCD()end
    return order
end
function ns.PartyCooldownOrder()return order end

local inspectTimer
local function InspectNext()
    inspectTimer=nil
    if InCombatLockdown and InCombatLockdown()then return end
    if not(NotifyInspect and CanInspect)then return end
    local soonest
    for _,name in ipairs(order)do local m=members[name]
        if m and not m.me and not m.addon and(not m.spec or not m.talented)and(m.tries or 0)<6 and(m.far or 0)<20 then
            local wait=m.asked and 15-(GetTime()-m.asked)or 0
            if wait<=0 then
                local ok,can=pcall(CanInspect,m.unit);if ok and can then m.asked=GetTime();m.tries=(m.tries or 0)+1;pcall(NotifyInspect,m.unit)
                    if C_Timer and C_Timer.NewTimer then inspectTimer=C_Timer.NewTimer(2,InspectNext)end;return end
                m.asked=GetTime();m.far=(m.far or 0)+1;if not soonest or soonest>15 then soonest=15 end
            elseif not soonest or wait<soonest then soonest=wait end
        end
    end
    if soonest and C_Timer and C_Timer.NewTimer then inspectTimer=C_Timer.NewTimer(soonest+0.1,InspectNext)end
end
local function ReadTalents(m,config)
    local T=C_Traits;if not(T and T.GetConfigInfo and T.GetTreeNodes and T.GetNodeInfo and T.GetEntryInfo and T.GetDefinitionInfo)then return false end
    config=config or(Constants and Constants.TraitConsts and Constants.TraitConsts.INSPECT_TRAIT_CONFIG_ID or-1)
    local marks=ns.PartyCooldownConfig().talentSpells
    local ok,info=pcall(T.GetConfigInfo,config);if not ok or type(info)~="table"or type(info.treeIDs)~="table"then return false end
    local talented={};local any=false;local ranks={};local read=false
    for _,tree in ipairs(info.treeIDs)do
        local ok2,nodes=pcall(T.GetTreeNodes,tree)
        for _,node in ipairs(ok2 and type(nodes)=="table"and nodes or{})do
            local ok3,n=pcall(T.GetNodeInfo,config,node)
            if ok3 and type(n)=="table"and type(n.entryIDs)=="table"then
                local active=type(n.activeEntry)=="table"and n.activeEntry.entryID
                local rank=ns.Plain(n.currentRank,"number")and n.currentRank or 0
                for _,entry in ipairs(n.entryIDs)do
                    local ok4,e=pcall(T.GetEntryInfo,config,entry);local def=ok4 and type(e)=="table"and e.definitionID
                    local ok5,d=pcall(T.GetDefinitionInfo,def or 0);local id=ok5 and type(d)=="table"and d.spellID
                    if ns.Plain(id,"number")and WANTED[id]then ranks[id]=math.max(ranks[id]or 0,(active==entry or #n.entryIDs==1)and rank or 0);read=true end
                    if ns.Plain(id,"number")and byID[id]then
                        marks[id]=true
                        talented[id]=talented[id]or(rank>0 and(active==entry or #n.entryIDs==1));any=true
                    end
                end
            end
        end
    end
    if any and m then m.talented=talented end
    if(any or read)and m then m.ranks=ranks end
    if any and m and not m.me and m.guid then inspected[m.guid]={spec=m.spec,talented=m.talented,ranks=m.ranks}end
    return any
end
local function ReadOwnTalents()
    local get=C_ClassTalents and C_ClassTalents.GetActiveConfigID
    local ok,config=pcall(get or function()end)
    local me;for _,m in pairs(members)do if m.me then me=m end end
    if ok and ns.Plain(config,"number")then return ReadTalents(me,config)end
    return false
end
ns.PartyCooldownReadOwnTalents=ReadOwnTalents
ns.PartyCooldownReadTalents=ReadTalents
local function QueueInspect()if not inspectTimer and C_Timer and C_Timer.NewTimer then inspectTimer=C_Timer.NewTimer(1,InspectNext)end end

function ns.PartyCooldownPayload()
    local spec=ns.Spec();local _,class=UnitClass("player");local parts={tostring(spec or 0)}
    local me;for _,x in pairs(members)do if x.me then me=x end end
    if not me or me.spec~=spec then me={me=true,spec=spec,used={},ranks=me and me.ranks}end
    local done={}
    local function add(id)
        id=ALIAS[id]or id
        if done[id]or #parts>60 then return end;done[id]=true
        parts[#parts+1]=id.."="..math.floor(ns.PartyCooldownLength(me,id)+0.5)
        local _,max=OwnCharges(id);if max and max>1 then parts[#parts+1]="c"..id.."="..math.min(5,max)end
    end
    for _,id in ipairs(ns.PartyCooldownClassSpells(class))do if ForSpec(byID[id],spec)and Known(id)and not(FACTION[id]and UnitFactionGroup and FACTION[id]~=UnitFactionGroup("player"))then add(id)end end
    if ns.PartyCooldownConfig().cdm then for _,id in ipairs(ns.CooldownManagerSpells())do add(id)end end
    return table.concat(parts,";")
end
function ns.CooldownManagerSpells()
    local out={};local v=C_CooldownViewer
    if not(v and v.GetCooldownViewerCategorySet and v.GetCooldownViewerCooldownInfo)then return out end
    local essential=Enum and Enum.CooldownViewerCategory and Enum.CooldownViewerCategory.Essential or 0
    local ok,ids=pcall(v.GetCooldownViewerCategorySet,essential);if not ok or type(ids)~="table"then return out end
    for _,cooldownID in ipairs(ids)do
        local ok2,info=pcall(v.GetCooldownViewerCooldownInfo,cooldownID)
        local id=ok2 and type(info)=="table"and(info.overrideSpellID or info.spellID)
        if ns.Plain(id,"number")and id>0 and Known(id)and BaseCooldown(id)>=60 then out[#out+1]=id end
    end
    return out
end
local lastShare,shareTimer,shareState,lastPayload=-100,nil,"never",nil
function ns.SharePartyCooldowns(force)
    local cfg=ns.PartyCooldownConfig();if not cfg.enabled or not cfg.share then return false end
    if InCombatLockdown and InCombatLockdown()then return false end
    local payload=ns.PartyCooldownPayload()
    if not force and not needSend and payload==lastPayload then return false end
    local wait=10-(GetTime()-lastShare)
    if not force and wait>0 then
        if not shareTimer and C_Timer and C_Timer.NewTimer then shareTimer=C_Timer.NewTimer(wait,function()shareTimer=nil;ns.SharePartyCooldowns(true)end)end
        return false
    end
    lastShare=GetTime();local sent=ns.Send("PCD",payload);shareState=sent and"queued"or"not sent"
    if sent then lastPayload=payload;needSend=false end
    if sent and askAgain then askAgain=false;ns.Send("PCDQ","1")end
    return sent
end
local function ReadPCD(m,text)
    local fields={};for f in(text..";"):gmatch("([^;]*);")do fields[#fields+1]=f end
    local spec=tonumber(fields[1]);if not spec or #fields>80 then return false end
    if spec>0 then
        local fits=not m.class
        for _,s in ipairs(m.class and ns.ClassSpecs and ns.ClassSpecs[m.class]or{})do if s==spec then fits=true end end
        if not fits then return false end
    end
    local known,cds,new,face,charges={},{},{},{},{}
    for i=2,#fields do
        local cid,n=fields[i]:match("^c(%d+)=(%d+)$");cid,n=tonumber(cid),tonumber(n)
        if cid and n and n>1 and n<=5 then charges[ALIAS[cid]or cid]=n end
        local id,cd=fields[i]:match("^(%d+)=(%d+)$");id,cd=tonumber(id),tonumber(cd)
        if id and cd and id>0 and cd>0 and cd<=1800 then
            if ALIAS[id]then face[ALIAS[id]]=id;id=ALIAS[id]end
            local info=byID[id]
            if not info then new[#new+1]={id,i}
            elseif info.class and m.class and info.class~=m.class and not(info.sent or info.added)then id=nil
            elseif info.added and info.class~=m.class then info.sent=true end
            if id then known[id]=true;cds[id]=cd end
        end
    end
    for _,x in ipairs(new)do if m.class then Register(x[1],m.class,800+x[2]).sent=true else known[x[1]],cds[x[1]]=nil,nil end end
    if spec>0 and m.spec and m.spec~=spec then Prune(m,spec)end
    if #fields<=60 then
        for id in pairs(m.used)do local info=byID[id]
            if info and info.class and info.class==m.class and not info.detected and not info.added and not known[id]then m.used[id]=nil;if m.hiddenCd then m.hiddenCd[id]=nil end end
        end
    end
    m.sentSpec=spec>0 and spec or nil;m.spec=m.sentSpec or m.spec;m.known=known;m.cds=cds;m.addon=true;m.sentAt=GetTime();m.face=face;m.listFull=#fields<=60
    for id in pairs(charges)do if not known[id]then charges[id]=nil end end;m.charges=charges
    if m.talented then for id in pairs(known)do m.talented[id]=true end end
    return true
end
local GROUP_CHANNELS={PARTY=true,RAID=true,INSTANCE_CHAT=true}
local function Sender(sender,channel,full)
    if channel~=nil and not GROUP_CHANNELS[channel]then return nil end
    return ns.FullName(full or sender)
end
ns.PartyCooldownSender=Sender
ns.CommHandlers.PCD=function(text,sender,channel,full)
    sender=Sender(sender,channel,full)
    if not sender or type(text)~="string"or #text>1000 then return end
    local m=members[sender]
    if not m then pendingPCD[sender]={text=text,at=GetTime()};return end
    pendingPCD[sender]=nil
    if ReadPCD(m,text)then ns.RebuildPartyCooldownSensors();ns.DrawPartyCooldowns()end
end
ns.CommHandlers.PCDQ=function(_,sender,channel,full)
    sender=Sender(sender,channel,full)
    if sender and members[sender]and not members[sender].me then needSend=true;ns.SharePartyCooldowns()end
end
function ReadPendingPCD()
    local read=false
    for name,p in pairs(pendingPCD)do
        if GetTime()-p.at>30 then pendingPCD[name]=nil
        elseif members[name]then pendingPCD[name]=nil;read=ReadPCD(members[name],p.text)or read end
    end
    if read and C_Timer and C_Timer.NewTimer then C_Timer.NewTimer(0,function()ns.RebuildPartyCooldownSensors();ns.DrawPartyCooldowns()end)end
end

local pendingLearn,LearnPending={},nil
local function Learn(id,since)
    if not(C_Spell and C_Spell.GetSpellCooldown)then return true end
    local start,dur,_,gcd=OwnInfo(id)
    local _,max,_,charge=OwnCharges(id);if max and charge and charge>1.5 then start,dur,gcd=1,charge,false end
    if not(ns.Plain(start,"number")and ns.Plain(dur,"number"))then return false end
    if ns.Plain(gcd,"boolean")and gcd or dur<=1.5 then
        return since~=nil and GetTime()-since>5
    end
    local me;for _,x in pairs(members)do if x.me then me=x end end
    local learned=ns.PartyCooldownConfig().learned;local key=ns.PartyCooldownLearnKey(me)
    learned[key]=learned[key]or{};learned[key][id]=math.floor(dur*10+0.5)/10
    return true
end
ns.PartyCooldownLearn=Learn
function LearnPending()
    for id,at in pairs(pendingLearn)do if Learn(id,at)then pendingLearn[id]=nil end end
end
local function RedrawLater(seconds)
    if not(C_Timer and C_Timer.NewTimer)then return end
    C_Timer.NewTimer(seconds+0.1,function()ns.DrawPartyCooldowns()end)
end
local function OwnerUnit(unit)
    if unit=="pet"then return"player"end
    local kind,n=unit:match("^(%a+)pet(%d+)$");if kind then return kind..n end
    return unit
end
ns.PartyCooldownOwnerUnit=OwnerUnit
function ns.PartyCooldownCast(unit,id)
    if not ns.Plain(unit,"string")then return false end
    unit=OwnerUnit(unit)
    local m
    for _,x in pairs(members)do if x.unit==unit then m=x end end
    if not m and UnitIsUnit then for _,x in pairs(members)do
        local ok,same=pcall(UnitIsUnit,unit,x.unit);if ok and same==true then m=x end
    end end
    if not m then return false end
    if not ns.Plain(id,"number")then m.hidden=(m.hidden or 0)+1;if m.me then m.hiddenCast=true end;return false end
    if ALIAS[id]then m.face=m.face or{};m.face[ALIAS[id]]=id;id=ALIAS[id]elseif m.face then m.face[id]=nil end
    m.seen=(m.seen or 0)+1
    local info=byID[id]
    if not info and ns.PartyCooldownConfig().detect and BaseCooldown(id)>=60 then info=Register(id,m.class,700+id%100);info.detected=true end
    if not info or not ns.PartyCooldownTracked(id,m.spec)or(info.class and m.class and info.class~=m.class and not(info.sent or info.detected))or(info.race and m.race~=info.race)then return false end
    if m.used[id]and GetTime()-m.used[id]<1 then return true end
    Started(m,id,GetTime(),"cast",KIND[id]=="kick"and MarkOf((m.me and"target")or(unit.."target"))or nil)
    if m.me and not Learn(id)then pendingLearn[id]=GetTime()end
    ns.DrawPartyCooldowns();RedrawLater(ns.PartyCooldownLength(m,id))
    return true
end
function ns.PartyCooldownReset()for _,m in pairs(members)do m.used={};m.hiddenCd=nil;m.hiddenCast=nil;m.chg=nil end;ns.DrawPartyCooldowns()end

local attached
local groups={}
local TITLES={main="Party cooldowns",kick="Interrupts",cc="Crowd control",stun="Stuns",move="Movement",potion="Potions"}
local Style={}
Style.defaults={align="LEFT",gap=2,alpha=100,numbers=0,nameSize=0,border="none",zoom="normal",offX=0,offY=0}
Style.keys={"main","kick","stun","cc","move","potion"}
ns.PartyStyleKeys=Style.keys
function ns.PartyStyle(key)
    local cfg=ns.PartyCooldownConfig()
    if type(cfg.styles)~="table"then cfg.styles={}end
    local saved=cfg.styles[key];if type(saved)~="table"then saved={};cfg.styles[key]=saved end
    local st={};for k,v in pairs(Style.defaults)do st[k]=v end
    if key=="cc"then st.align="CENTER"end -- like the game's cooldown manager
    for k,v in pairs(saved)do if Style.defaults[k]~=nil and type(v)==type(Style.defaults[k])then st[k]=v end end
    st.gap=math.max(0,math.min(20,st.gap));st.alpha=math.max(10,math.min(100,st.alpha))
    return st,saved
end
Style.zoom={normal={0.07,0.93},zoom={0.15,0.85},full={0,1}}
function Style.Icon(icon,st)
    local z=Style.zoom[st.zoom]or Style.zoom.normal
    icon.tex:SetTexCoord(z[1],z[2],z[1],z[2])
    if icon.ownGrey then icon.ownGrey:SetTexCoord(z[1],z[2],z[1],z[2])end
    local edge=st.border=="thin"and 1 or st.border=="thick"and 2 or 0
    if edge>0 then
        if not icon.border then icon.border=icon:CreateTexture(nil,"BACKGROUND",nil,-8);icon.border:SetColorTexture(0,0,0,1)end
        icon.border:ClearAllPoints();icon.border:SetPoint("TOPLEFT",icon,"TOPLEFT",-edge,edge);icon.border:SetPoint("BOTTOMRIGHT",icon,"BOTTOMRIGHT",edge,-edge);icon.border:Show()
    elseif icon.border then icon.border:Hide()end
    local fs=icon.cd and icon.cd.GetCountdownFontString and icon.cd:GetCountdownFontString()
    if fs and fs.GetFont then
        if not icon.numberFont then icon.numberFont={fs:GetFont()}end
        local f=icon.numberFont
        if st.numbers>0 then pcall(fs.SetFont,fs,f[1],st.numbers,"OUTLINE")elseif f[1]then pcall(fs.SetFont,fs,f[1],f[2],f[3])end
    end
end
ns.PartyStyleIcon=Style.Icon
function Style.Shift(st,free,back)
    if st.align=="CENTER"then return free/2 end
    if(st.align=="RIGHT"and not back)or(st.align=="LEFT"and back)then return free end
    return 0
end
ns.PartyAlignShift=Style.Shift
local function Place(key)
    local cfg=ns.PartyCooldownConfig()
    if key=="main"then return cfg.pos end
    return cfg.anchors[key]
end
local function Group(key)
    local g=groups[key];if g then return g end
    local f=CreateFrame("Frame",nil,UIParent);f:SetFrameStrata("MEDIUM");f:SetSize(200,30)
    f.bg=f:CreateTexture(nil,"BACKGROUND");f.bg:SetAllPoints();f.bg:SetColorTexture(0.6,0.36,1,0.25)
    f.title=f:CreateFontString(nil,"OVERLAY","GameFontNormal");f.title:SetPoint("BOTTOMLEFT",f,"TOPLEFT",2,2);f.title:SetText(L(TITLES[key]))
    f:SetMovable(true);f:SetClampedToScreen(true);f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",function(self)if ns.PartyCooldownConfig().unlocked then self:StartMoving()end end)
    f:SetScript("OnDragStop",function(self)
        self:StopMovingOrSizing()
        local x,y=self:GetCenter();local ux,uy=UIParent:GetCenter()
        if type(x)=="number"and type(ux)=="number"then
            local pos=Place(key);pos.x,pos.y=math.floor(x-ux+0.5),math.floor(y-uy+0.5);g.x,g.y=pos.x,pos.y
        end
    end)
    f:Hide()
    g={key=key,frame=f,rows={}};groups[key]=g
    return g
end
ns.PartyCooldownGroups=groups
local function Anchor(g)
    local pos=Place(g.key);local x,y=tonumber(pos.x)or 0,tonumber(pos.y)or 0
    if g.x~=x or g.y~=y then g.frame:ClearAllPoints();g.frame:SetPoint("CENTER",UIParent,"CENTER",x,y);g.x,g.y=x,y end
end
local function Row(g,i)
    local row=g.rows[i];if row then return row end
    row=CreateFrame("Frame",nil,g.frame);row.name=row:CreateFontString(nil,"OVERLAY","GameFontNormal");row.icons={};g.rows[i]=row
    return row
end
local function Icon(row,i,size)
    local icon=row.icons[i]
    if not icon then
        icon=CreateFrame("Frame",nil,row);icon.tex=icon:CreateTexture(nil,"ARTWORK");icon.tex:SetAllPoints();icon.tex:SetTexCoord(0.07,0.93,0.07,0.93)
        icon.cd=CreateFrame("Cooldown",nil,icon,"CooldownFrameTemplate");icon.cd:SetAllPoints();row.icons[i]=icon
        -- This addon owns the countdown text, including the hidden-time display.
        icon.cd.noCooldownCount=true;icon.cd.noOCC=true
        pcall(icon.cd.SetDrawEdge,icon.cd,false);pcall(icon.cd.SetDrawBling,icon.cd,false)
        icon.approx=icon.cd:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");icon.approx:SetPoint("TOPRIGHT",icon,"TOPRIGHT",-1,-1);icon.approx:SetText("~");icon.approx:Hide()
        icon.hl=icon:CreateTexture(nil,"BACKGROUND");icon.hl:SetPoint("TOPLEFT",icon,"TOPLEFT",-2,2);icon.hl:SetPoint("BOTTOMRIGHT",icon,"BOTTOMRIGHT",2,-2)
        icon.hl:SetColorTexture(1,0.82,0,1);icon.hl:Hide()
        icon.mark=icon.cd:CreateTexture(nil,"OVERLAY");icon.mark:SetPoint("TOPLEFT",icon,"TOPLEFT",-2,2);icon.mark:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons");icon.mark:Hide()
        icon:SetScript("OnEnter",function(self)ns.PartyCooldownTooltip(self)end)
        icon:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end)
    end
    icon:SetSize(size,size);return icon
end
function ns.PartyCooldownTooltip(icon)
    if not(GameTooltip and icon.spellID and ns.PartyCooldownConfig().tooltip)then return end
    GameTooltip:SetOwner(icon,"ANCHOR_RIGHT");pcall(GameTooltip.SetSpellByID,GameTooltip,icon.spellID)
    local m=icon.member and members[icon.member]
    if m then
        local left=ns.PartyCooldownLeft(m,icon.spellID);local own=OwnHidden(m,icon.spellID)
        local state=left>0 and not own and((ns.PartyCooldownExact(m,icon.spellID)and""or"~")..math.ceil(left).." s")
            or(own and ObjectZero(own)~=true and"?")or L("ready")
        GameTooltip:AddLine(ns.PartyName(m.name)..": "..state,1,1,1)
    end
    GameTooltip:Show()
end
local function Dress(icon,m,id,left,mark)
    local cfg=ns.PartyCooldownConfig()
    if not icon.count then icon.count=icon.cd:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");icon.count:SetPoint("BOTTOMRIGHT",icon,"BOTTOMRIGHT",-1,1)end
    local avail,max,rs,rd=ns.PartyCooldownCharges(m,id)
    if max then icon.count:SetText(tostring(avail));icon.count:Show()else icon.count:SetText("");icon.count:Hide()end
    local recharge=max and left<=0 and rs and rd and not(m.me and OwnHidden(m,id))
    if recharge then icon.cd:SetCooldown(rs,rd)end
    icon.member=m.name;pcall(icon.EnableMouse,icon,cfg.tooltip==true)
    local start=m.used and m.used[id]
    if cfg.highlight and left>0 and start and GetTime()-start<HIGHLIGHT then icon.hl:Show()else icon.hl:Hide()end
    local i=mark and left>0 and m.marks and m.marks[id]
    if i and SetRaidTargetIconTexture then icon.mark:SetSize(math.max(10,icon:GetWidth()*0.5),math.max(10,icon:GetWidth()*0.5));SetRaidTargetIconTexture(icon.mark,i);icon.mark:Show()else icon.mark:Hide()end
    return recharge
end
ns.PartyCooldownDress=Dress
local frameCache,lastScan={},nil -- frames found, and the group they were looked up for
local StartWalk -- the walk over every frame, a few hundred at a time
local lastGroup,retries=nil,0 -- walks again for frames that were not there yet
function ns.PartyCooldownForgetFrames()frameCache={};lastScan=nil end
local FRAME_NAMES={"CompactPartyFrameMember%d","CompactRaidFrame%d","ElvUF_PartyGroup1UnitButton%d"}
local function Seen(f)
    if not f:IsVisible()then return false end
    local a=f.GetEffectiveAlpha and f:GetEffectiveAlpha()
    return not ns.Plain(a,"number")or a>0.05
end
ns.PartyCooldownFrameSeen=Seen
local function UnitFrame(unit)
    if not UnitIsUnit then return nil end
    local function match(f)
        if type(f)~="table"or not f.IsVisible or not Seen(f)then return false end
        local u=f.unit or(f.GetAttribute and f:GetAttribute("unit"))
        if not ns.Plain(u,"string")then return false end
        local ok,same=pcall(UnitIsUnit,u,unit);return ok and same==true
    end
    for _,pattern in ipairs(FRAME_NAMES)do for i=1,40 do
        local f=_G[pattern:format(i)];if f==nil and i>5 then break end
        if match(f)then return f end
    end end
    for g=1,8 do for i=1,5 do
        local f=_G[("CompactRaidGroup%dMember%d"):format(g,i)];if match(f)then return f end
        f=_G[("ElvUF_RaidGroup%dUnitButton%d"):format(g,i)];if match(f)then return f end
    end end
    local cached=frameCache[unit]
    if type(cached)=="table"and match(cached)then return cached end
    local group=table.concat(order,",")
    if InCombatLockdown and InCombatLockdown()or not EnumerateFrames or lastScan==group then return nil end
    if lastGroup~=group then lastGroup=group;retries=0 end
    lastScan=group;StartWalk()
    return nil
end
local walker,walk=nil,nil
local function Look(f)
    if f.IsForbidden and f:IsForbidden()or not Seen(f)then return nil end
    local u=rawget(f,"unit")or(f.GetAttribute and f:GetAttribute("unit"))
    return ns.Plain(u,"string")and(f:GetHeight()or 0)>=16 and u or nil
end
local function Area(f)
    local ok,w,h=pcall(function()return f:GetWidth(),f:GetHeight()end)
    if not ok or not ns.Plain(w,"number")or not ns.Plain(h,"number")or w>400 or h>200 then return -1 end
    return w*h
end
local function Step()
    if InCombatLockdown and InCombatLockdown()then return end -- goes on after combat
    Timed("frame scan",function()
        local f=walk.at
        for _=1,250 do
            if not f then break end
            local ok,u=pcall(Look,f)
            if ok and u and f~=TargetFrame and f~=FocusFrame then
                local best=walk.found[u];local area=Area(f)
                if area>=0 and(not best or(best==PlayerFrame and f~=PlayerFrame)or(f~=PlayerFrame and area>walk.area[u]))then walk.found[u]=f;walk.area[u]=area end
            end
            f=EnumerateFrames(f)
        end
        walk.at=f
    end)
    if walk.at then return end
    for u,fr in pairs(walk.found)do frameCache[u]=fr end
    walk=nil;walker:SetScript("OnUpdate",nil);ns.DrawPartyCooldowns()
    local missing=false
    for _,name in ipairs(order)do local m=members[name]
        if m and m.unit and not m.me and not frameCache[m.unit]then missing=true end
    end
    retries=retries+1
    if missing and retries<=3 and C_Timer and C_Timer.NewTimer then
        C_Timer.NewTimer(10,function()lastScan=nil;ns.DrawPartyCooldowns()end)
    end
end
function ns.PartyCooldownFinishWalk()while walk and not(InCombatLockdown and InCombatLockdown())do Step()end end
StartWalk=function()
    if walk then return end
    walker=walker or CreateFrame("Frame")
    walk={at=EnumerateFrames(),found={},area={}}
    walker:SetScript("OnUpdate",Step)
end
ns.PartyCooldownFrame=UnitFrame
local ShowHidden -- hidden timers on icons, defined with the buff sensors
local SIDES={RIGHT={"LEFT","RIGHT",2,0,1,0},LEFT={"RIGHT","LEFT",-2,0,-1,0},TOP={"BOTTOMLEFT","TOPLEFT",0,2,1,0},BOTTOM={"TOPLEFT","BOTTOMLEFT",0,-2,1,0}}
local function MaybeRunning(m,id)
    local own=m.me and OwnHidden(m,id);if not own then return nil end
    local zero=ObjectZero(own);if zero~=nil then return not zero end
    return(m.used[id]or m.hiddenCast)and true or nil
end
local function Visible(m,ids,cfg)
    if not cfg.hideReady then return #ids end
    local n=0;for _,id in ipairs(ids)do if ns.PartyCooldownLeft(m,id)>0 or Hidden(m,id)or MaybeRunning(m,id)then n=n+1 end end;return n
end
local function Grid(n,size,cfg)
    local per=math.floor(tonumber(cfg.perRow)or 0)
    if per>0 and n>per then return per,tonumber(cfg.size2)or 20 end
    return math.max(1,n),size
end
ns.PartyCooldownGrid=Grid
local function FillIcons(row,m,ids,size,cfg)
    local n=0;local st=ns.PartyStyle("main")
    for _,id in ipairs(ids)do
        local left=ns.PartyCooldownLeft(m,id)
        local hidden=Hidden(m,id);local own=OwnHidden(m,id)
        if not(cfg.hideReady and left<=0 and not hidden and not MaybeRunning(m,id))then
            n=n+1;local icon=Icon(row,n,size);Style.Icon(icon,st)
            icon.tex:SetTexture(W.SpellTexture(m.face and m.face[id]or id));icon.spellID=id
            local start,dur;if m.me then start,dur=OwnCooldown(id)end
            if start==0 then start=nil elseif not start and m.used[id]then start,dur=m.used[id],ns.PartyCooldownLength(m,id)end
            if icon.ownGrey then icon.ownGrey:Hide()end
            if own and own~=true then DrawOwnHidden(icon.cd,own);OwnGrey(icon,own)
            elseif left>0 and start then icon.cd:SetCooldown(start,dur);icon.tex:SetDesaturated(true)
            else icon.cd:Clear();icon.tex:SetDesaturated(false)end
            if(left>0 or hidden)and not ns.PartyCooldownExact(m,id)then icon.approx:Show()else icon.approx:Hide()end
            local recharge=Dress(icon,m,id,left,false)
            local plain=(own and own~=true)or(left>0 and start)or recharge
            icon:Show();ShowHidden(icon,not plain and hidden or nil)
        end
    end
    for i=n+1,#row.icons do row.icons[i]:Hide();ShowHidden(row.icons[i],nil)end
    return n
end
local function DrawRows(g,entries,opts,unlocked)
    local f=g.frame;Anchor(g)
    local size=tonumber(opts.size)or 26;local font=W.Font and W.Font(true);local y,widest=0,0
    local up=opts.grow=="UP";local st=ns.PartyStyle("main");local gap=st.gap;f:SetAlpha(st.alpha/100)
    for i,e in ipairs(entries)do
        local m,ids=e[1],e[2]
        local row=Row(g,i)
        row:ClearAllPoints()
        if up then row:SetPoint("BOTTOMLEFT",f,"BOTTOMLEFT",4,y+4)else row:SetPoint("TOPLEFT",f,"TOPLEFT",4,-y-4)end
        row:SetSize(1,size)
        if type(font)=="string"then row.name:SetFont(font,st.nameSize>0 and st.nameSize or 12,"OUTLINE")end
        local c=m.class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[m.class]
        row.name:SetTextColor(c and c.r or 1,c and c.g or 1,c and c.b or 1)
        local start=opts.names and 94 or 6
        if not row.bar then row.bar=row:CreateTexture(nil,"ARTWORK")end
        row.bar:SetColorTexture(c and c.r or 1,c and c.g or 1,c and c.b or 1,1);row.bar:ClearAllPoints();row.bar:SetPoint("LEFT",row,"LEFT",0,0);row.bar:SetSize(3,size)
        if opts.names then row.name:SetText(ns.PartyName(m.name));row.name:Show();row.bar:Hide()else row.name:SetText("");row.name:Hide();row.bar:Show()end
        row.name:ClearAllPoints();row.name:SetPoint("LEFT",row,"LEFT",0,0);row.name:SetWidth(90)
        local per,s=Grid(Visible(m,ids,opts),size,opts)
        local n=FillIcons(row,m,ids,s,opts);local lines=math.max(1,math.ceil(n/per))
        row:SetSize(1,lines*(s+gap)-gap);row.bar:SetHeight(lines*(s+gap)-gap)
        local short=n>per and n%per or 0;local shift=short>0 and Style.Shift(st,(per-short)*(s+gap),false)or 0
        for k=1,n do local icon=row.icons[k];icon:ClearAllPoints()
            icon:SetPoint("TOPLEFT",row,"TOPLEFT",start+((k-1)%per)*(s+gap)+(k>n-short and shift or 0),-math.floor((k-1)/per)*(s+gap))end
        widest=math.max(widest,start+math.min(n,per)*(s+gap));row:Show();y=y+math.max(size,lines*(s+gap)-gap)+4
    end
    for i=#entries+1,#g.rows do g.rows[i]:Hide()end
    f:SetSize(math.max(60,widest+8),math.max(size+8,y+4));f:EnableMouse(unlocked==true)
    f.title:SetText(L(TITLES[g.key]))
    if unlocked then f.bg:Show();f.title:Show()else f.bg:Hide();f.title:Hide()end
    if #entries>0 or unlocked then f:Show()else f:Hide()end
    return #entries
end
local GAME_BARS={{value="",label="Blizzard",file="Interface\\TargetingFrame\\UI-StatusBar"},{value="flat",label="Flat",file="Interface\\Buttons\\WHITE8X8"},
    {value="raid",label="Raid frame",file="Interface\\RaidFrame\\Raid-Bar-Hp-Fill"},{value="skills",label="Skill bar",file="Interface\\PaperDollInfoFrame\\UI-Character-Skills-Bar"}}
local function SharedMedia()return LibStub and LibStub("LibSharedMedia-3.0",true)end
function ns.PartyBarTextures()
    local out={};for _,t in ipairs(GAME_BARS)do out[#out+1]={value=t.value,label=L(t.label)}end
    local lsm=SharedMedia();if lsm and lsm.List then local ok,list=pcall(lsm.List,lsm,"statusbar")
        if ok and type(list)=="table"then for _,name in ipairs(list)do out[#out+1]={value="lsm:"..name,label=name}end end end
    return out
end
local function BarFile(choice)
    for _,t in ipairs(GAME_BARS)do if t.value==choice then return t.file end end
    if type(choice)=="string"and choice:sub(1,4)=="lsm:"then local lsm=SharedMedia()
        local ok,file=pcall(function()return lsm and lsm:Fetch("statusbar",choice:sub(5),true)end);if ok and type(file)=="string"then return file end end
    return GAME_BARS[1].file
end
ns.PartyBarFile=BarFile
local function CellSpellName(id)
    local ok,name=pcall(C_Spell and C_Spell.GetSpellName or function()end,id)
    return ok and ns.Plain(name,"string")and name or""
end
local function Timing(m,id)
    local start,dur;if m.me then start,dur=OwnCooldown(id)end
    if start==0 then start=nil elseif not start and m.used[id]then start,dur=m.used[id],ns.PartyCooldownLength(m,id)end
    local left=start and math.max(0,start+dur-GetTime())or 0
    return left,start,dur,Hidden(m,id)
end
local function Cell(g,i)
    local f=g.frame;f.icons=f.icons or{}
    local cell=Icon(f,i,10)
    if not cell.bar then
        local bar=CreateFrame("StatusBar",nil,f);bar:SetStatusBarTexture(GAME_BARS[1].file);bar:SetMinMaxValues(0,1);bar:SetValue(1)
        bar.bg=bar:CreateTexture(nil,"BACKGROUND");bar.bg:SetAllPoints();bar.bg:SetColorTexture(0,0,0,0.55)
        bar.textLayer=CreateFrame("Frame",nil,bar);bar.textLayer:SetAllPoints(bar);bar.textLayer:SetFrameLevel(bar:GetFrameLevel()+3)
        bar.name=bar.textLayer:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        bar.time=bar.textLayer:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        cell.bar=bar
        cell.label=cell:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    end
    return cell
end
local function PotionShade(bar,track,now)
    if not track then
        for _,shade in ipairs(bar.shades or{})do shade:Hide()end
        return
    end
    bar.shades=bar.shades or{}
    for k=1,2 do
        local shade=bar.shades[k]
        if not shade then
            shade=CreateFrame("StatusBar",nil,bar);shade:SetAllPoints(bar)
            shade:SetFrameLevel(bar:GetFrameLevel()+1)
            shade:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
            shade:SetStatusBarColor(0.2,0.2,0.22,1);shade:SetReverseFill(true)
            bar.shades[k]=shade
        end
        local sl=track.slot[k];local low=(now-sl.epoch)/track.window
        -- Pass the encoded (possibly secret) expiry straight to the widget.
        -- Gray covers the remaining portion on the right, revealing color on the left.
        shade:SetMinMaxValues(low,low+track.cd/track.window);shade:SetValue(sl.code);shade:Show()
    end
end
local function UpdateBars(self,elapsed)
    self.wait=(self.wait or 0)-(elapsed or 0);if self.wait>0 then return end;self.wait=0.1
    local now=GetTime()
    for _,cell in ipairs(self.icons or{})do local bar=cell.bar
        if bar and bar:IsShown()then
            PotionShade(bar,bar.progressForward and bar.hiddenTrack or nil,now)
            if bar.object then bar.time:SetText("")
            elseif bar.progressForward and bar.hiddenTrack then
                bar:SetMinMaxValues(0,1);bar:SetValue(1);bar.time:SetText("")
            else
                local left=bar.start and bar.start+bar.dur-now or 0
                if left>0 then bar:SetMinMaxValues(0,bar.dur);bar:SetValue(bar.progressForward and math.max(0,bar.dur-left)or left);bar.time:SetText((bar.approx and"~"or"")..math.ceil(left))
                else bar:SetMinMaxValues(0,1);bar:SetValue(bar.hidden and 0 or 1);bar.time:SetText("")end
            end
        end
    end
end
local function DrawAnchor(g,entries,a,unlocked)
    local f=g.frame;Anchor(g)
    local bars=a.style=="bars";local size=tonumber(a.size)or 26;local width=bars and math.max(size+20,tonumber(a.width)or 180)or size
    local perRow=math.max(1,math.floor(tonumber(a.perRow)or 1));local rows=math.max(1,math.floor(tonumber(a.rows)or 5))
    local st=ns.PartyStyle(g.key);f:SetAlpha(st.alpha/100)
    local left,up,gap=a.dir=="LEFT",a.grow=="UP",st.gap
    local nameSize=st.nameSize>0 and st.nameSize
    local h,v=left and"RIGHT"or"LEFT",up and"BOTTOM"or"TOP"
    local font=W.Font and W.Font(true)
    local n=0
    for _,e in ipairs(entries)do local m=e[1]
        for _,id in ipairs(e[2])do
            local remain,start,dur,hidden=Timing(m,id);local own=OwnHidden(m,id)
            if n<perRow*rows and not(a.hideReady and remain<=0 and not hidden and not MaybeRunning(m,id))then
                n=n+1;local cell=Cell(g,n);local col,row=(n-1)%perRow,math.floor((n-1)/perRow);Style.Icon(cell,st)
                cell:ClearAllPoints();cell:SetSize(size,size)
                cell:SetPoint(v..h,f,v..h,(left and-1 or 1)*(3+col*(width+gap)),(up and 1 or-1)*(3+row*(size+gap)))
                cell.tex:SetTexture(W.SpellTexture(m.face and m.face[id]or id));cell.spellID=id;cell.member=m.name
                local object=own and own~=true and own
                if cell.ownGrey then cell.ownGrey:Hide()end
                if object then DrawOwnHidden(cell.cd,object);OwnGrey(cell,object)
                elseif remain>0 and start then cell.cd:SetCooldown(start,dur);cell.tex:SetDesaturated(true)
                else cell.cd:Clear();cell.tex:SetDesaturated(false)end
                local approx=(remain>0 or hidden)and not ns.PartyCooldownExact(m,id)
                if approx and not bars then cell.approx:Show()else cell.approx:Hide()end
                if cell.cd.SetHideCountdownNumbers then cell.cd:SetHideCountdownNumbers(bars and not object)end
                local recharge=Dress(cell,m,id,remain,a.mark)
                local plain=object or(remain>0 and start)
                cell:Show();ShowHidden(cell,not(plain or recharge)and hidden or nil)
                local c=m.class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[m.class]
                local r,gr,b=c and c.r or 0.6,c and c.g or 0.36,c and c.b or 1
                local bar,label=cell.bar,cell.label
                local name=ns.PartyName(m.name)
                if bars then
                    bar:ClearAllPoints();bar:SetSize(width-size-gap,size)
                    if left then bar:SetPoint("RIGHT",cell,"LEFT",-gap,0)else bar:SetPoint("LEFT",cell,"RIGHT",gap,0)end
                    bar.progressForward=g.key=="potion"
                    if bar.SetReverseFill then bar:SetReverseFill(not bar.progressForward and left)end
                    local file=BarFile(a.texture);if bar.file~=file then bar.file=file;bar:SetStatusBarTexture(file)end
                    if bar.progressForward then bar.bg:SetColorTexture(0.2,0.2,0.22,1)else bar.bg:SetColorTexture(0,0,0,0.55)end
                    if a.dark and not bar.progressForward then bar:SetStatusBarColor(0.16,0.16,0.18,1);bar.name:SetTextColor(r,gr,b)else bar:SetStatusBarColor(r,gr,b,1);bar.name:SetTextColor(1,1,1)end
                    bar.start,bar.dur,bar.hidden,bar.approx=(not object and remain>0)and start or nil,dur,hidden~=nil or own~=nil,approx
                    bar.hiddenTrack=not plain and hidden or nil
                    -- A plain timer reaching zero is ready even if an old sensor track remains.
                    if plain then bar.hidden=false end
                    bar.object=nil
                    if object and bar.SetTimerDuration then
                        local E=Enum;local direction=E and E.StatusBarTimerDirection
                        local ok=pcall(bar.SetTimerDuration,bar,object,E and E.StatusBarInterpolation and E.StatusBarInterpolation.Immediate,direction and(bar.progressForward and direction.ElapsedTime or direction.RemainingTime))
                        if ok then bar.object=object end
                    end
                    if type(font)=="string"then bar.name:SetFont(font,nameSize or 11,"OUTLINE");bar.time:SetFont(font,nameSize or 11,"OUTLINE")end
                    bar.name:ClearAllPoints();bar.time:ClearAllPoints()
                    bar.name:SetPoint(left and"RIGHT"or"LEFT",bar,left and"RIGHT"or"LEFT",left and-4 or 4,0)
                    bar.time:SetPoint(left and"LEFT"or"RIGHT",bar,left and"LEFT"or"RIGHT",left and 4 or-4,0)
                    bar.name:SetText(a.names and name or CellSpellName(id))
                    bar:Show();label:Hide()
                else
                    bar:Hide();bar.start=nil
                    if a.names then
                        if type(font)=="string"then label:SetFont(font,nameSize or 9,"OUTLINE")end
                        label:ClearAllPoints();label:SetPoint("BOTTOM",cell,"BOTTOM",0,1);label:SetWidth(size)
                        label:SetText(name);label:SetTextColor(r,gr,b);label:Show()
                    else label:Hide()end
                end
            end
        end
    end
    local short=n>perRow and n%perRow or 0
    local shift=short>0 and Style.Shift(st,(perRow-short)*(width+gap),left)or 0
    if short>0 and shift~=0 then
        local row=math.floor((n-1)/perRow)
        for i=n-short+1,n do local cell=f.icons[i];local col=(i-1)%perRow
            cell:ClearAllPoints();cell:SetPoint(v..h,f,v..h,(left and-1 or 1)*(3+col*(width+gap)+shift),(up and 1 or-1)*(3+row*(size+gap)))
        end
    end
    for i=n+1,#(f.icons or{})do local cell=f.icons[i];cell:Hide();ShowHidden(cell,nil);if cell.bar then cell.bar:Hide();cell.bar.start=nil end end
    local cols=math.max(1,math.min(perRow,n));local used=math.max(1,math.ceil(n/perRow))
    f:SetSize(cols*(width+gap)+4,used*(size+gap)+4);f:EnableMouse(unlocked==true)
    f.title:SetText(L(TITLES[g.key]))
    if unlocked then f.bg:Show();f.title:Show()else f.bg:Hide();f.title:Hide()end
    if n>0 or unlocked then f:Show()else f:Hide()end
    if bars and n>0 then f.wait=0;f:SetScript("OnUpdate",UpdateBars);UpdateBars(f,0)else f:SetScript("OnUpdate",nil)end
    return n
end
ns.PartyCooldownUpdateBars=UpdateBars
function ns.PartyCooldownsLoaded()
    local cfg=ns.PartyCooldownConfig()
    if cfg.loadSolo==false and not(IsInGroup and IsInGroup())then return false end
    if cfg.loadWhere=="instances"or cfg.loadWhere=="dungeons"then
        local ok,inside,kind=pcall(IsInInstance or function()end)
        if not(ok and inside)then return false end
        if cfg.loadWhere=="dungeons"and kind~="party"then return false end
    end
    return true
end
local DrawNow
function ns.DrawPartyCooldowns()return Timed("draw",DrawNow)end
DrawNow=function()
    local cfg=ns.PartyCooldownConfig()
    attached=attached or{}
    for _,a in pairs(attached)do a:Hide()end
    if not((cfg.enabled and ns.PartyCooldownsLoaded())or cfg.unlocked)then for _,g in pairs(groups)do g.frame:Hide()end;return false end
    ns.PartyCooldownRoster()
    local size=tonumber(cfg.size)or 26
    local selfOn,anySelf={},cfg.self or cfg.unlocked
    for _,key in ipairs(LISTS)do selfOn[key]=cfg.anchors[key].self~=false;anySelf=anySelf or selfOn[key]end
    local names,others={},0
    for _,name in ipairs(order)do local me=members[name]and members[name].me
        if not me then others=others+1 end
        if not me or anySelf then names[#names+1]=name end
    end
    local preview=cfg.unlocked and others==0
    if #names==0 and cfg.unlocked then
        local _,class=UnitClass("player");local me=ns.UnitFullName("player")or"Player"
        members[me]=members[me]or{name=me,used={},me=true,class=class,spec=ns.Spec()};names={me}
    end
    local main,lists={},{};for _,key in ipairs(LISTS)do lists[key]={}end
    for _,name in ipairs(names)do
        local m=members[name];m.name=m.name or name
        local ids=ns.PartyCooldownList(m,"defensive")
        local frame=cfg.mode=="frames"and m.unit and UnitFrame(m.unit)
        if m.me and not cfg.self and not preview then -- your own icons are hidden in the main list
        elseif frame then
            local holder=attached[name]
            if not holder then holder=CreateFrame("Frame",nil,UIParent);holder.icons={};attached[name]=holder end
            local side=SIDES[cfg.side]or SIDES.RIGHT
            local per,s=Grid(Visible(m,ids,cfg),size,cfg)
            local n=FillIcons(holder,m,ids,s,cfg);local lines=math.max(1,math.ceil(n/per))
            local st=ns.PartyStyle("main");local gap=st.gap;holder:SetAlpha(st.alpha/100)
            holder:ClearAllPoints();holder:SetPoint(side[1],frame,side[2],side[3]+st.offX,side[4]+st.offY);holder:SetSize(math.max(1,math.min(n,per)*(s+gap)),lines*(s+gap)-gap)
            local short=n>per and n%per or 0;local shift=short>0 and Style.Shift(st,(per-short)*(s+gap),side[5]<0)or 0
            for i=1,n do local icon=holder.icons[i];icon:ClearAllPoints();local col,line=(i-1)%per,math.floor((i-1)/per)
                local x=col*(s+gap)+(i>n-short and shift or 0)
                if side[5]>0 then icon:SetPoint("TOPLEFT",holder,"TOPLEFT",x,-line*(s+gap))else icon:SetPoint("TOPRIGHT",holder,"TOPRIGHT",-x,-line*(s+gap))end
            end
            holder:Show()
        else main[#main+1]={m,ids}end
        local own=m.me and not preview
        for _,key in ipairs(LISTS)do
            local ids2=(selfOn[key]or not own)and ns.PartyCooldownList(m,key)or{}
            if #ids2>0 then local l=lists[key];l[#l+1]={m,ids2}end
        end
    end
    DrawRows(Group("main"),main,cfg,cfg.unlocked)
    local raid=IsInRaid and IsInRaid()
    for _,key in ipairs(LISTS)do local a=cfg.anchors[key]
        local on=cfg[FIELD[key]]~=false and not(a.hideInRaid and raid)
        DrawAnchor(Group(key),on and lists[key]or{},a,cfg.unlocked and on)
    end
    return true
end

local SELF,EXTERNAL,ENEMY=1,2,3
local BUFFS={
    [49028]={SELF,81256},[48707]={SELF,48707,444741},[51052]={EXTERNAL,51052,145629},
    [198589]={SELF,212800},[196718]={EXTERNAL,209426},
    [194223]={SELF,194223,102560,390414},[102560]={SELF,102560,390414},[106951]={SELF,106951,102543},[102543]={SELF,102543},
    [740]={EXTERNAL,740,157982,1264623},[33891]={SELF,117679,33891},[102342]={EXTERNAL,102342},[106898]={EXTERNAL,106898,77761,77764},
    [357170]={EXTERNAL,357170},[374227]={EXTERNAL,374227},
    [19574]={SELF,19574,186254,1235388,1285912},[365350]={SELF,365350,365362},[45438]={SELF,45438,414658},[414658]={SELF,414658,45438},
    [342245]={SELF,342246},[80353]={EXTERNAL,80353},
    [123904]={SELF,123904,1248992},[115203]={SELF,115203,120954},[116849]={EXTERNAL,116849},
    [31884]={SELF,31884,231895,454351,216331,389539},[231895]={SELF,231895,31884},[216331]={SELF,216331,31884},
    [498]={SELF,498,403876},[403876]={SELF,403876,498},[31821]={EXTERNAL,31821},
    [1022]={EXTERNAL,1022,204018},[6940]={EXTERNAL,6940},[204018]={EXTERNAL,204018},
    [62618]={EXTERNAL,81782},[228260]={SELF,194249},[10060]={EXTERNAL,10060},[33206]={EXTERNAL,33206},[47788]={EXTERNAL,47788},
    [64843]={EXTERNAL,64843,64844},[360194]={SELF,1249810,360194},
    [114050]={SELF,114050,1219480},[98008]={EXTERNAL,325174},[198103]={SELF,198103,381755},[2825]={EXTERNAL,2825},[32182]={EXTERNAL,32182},
    [265187]={SELF,1276767,265187},[1122]={SELF,1122,111685,266087,417282},
    [192077]={EXTERNAL,192082},[1044]={EXTERNAL,1044},[116841]={EXTERNAL,116841},[1250646]={SELF,1250646,1251703},
    [66]={SELF,66,32612,110960,113862},[1856]={SELF,11327},[20594]={SELF,65116},
    [374968]={EXTERNAL,375226,375229,375230,375234,375238,375240,375252,375253,375254,375255,375256,375257,375258},
    [97462]={EXTERNAL,97463},[227847]={SELF,227847,446035},[107574]={SELF,107574,401150},
}
for id,debuffs in pairs({[119381]={119381},[179057]={179057},[30283]={30283},[192058]={118905},[46968]={132168},[109248]={117405,117526},
    [853]={853},[19577]={24394,474421},[207167]={207167},[115750]={105421},[8122]={8122},[99]={99},[5246]={5246},[207684]={207685},
    [202138]={204843},[108199]={374776},[102793]={127797},[132469]={61391},[2094]={2094}})do BUFFS[id]={ENEMY,unpack(debuffs)}end
BUFFS[POTION]={SELF,unpack(POTIONS)}
local LAG={[192058]=2,[207684]=2,[202138]=2}
local PLATES=40
local SENSE_PLATES=12
ns.PartyCooldownBuffs=BUFFS
local function BuffsOf(id)
    local b=BUFFS[id];if not b then return SELF,{[id]=true}end
    local set={};for i=2,#b do set[b[i]]=true end
    return b[1],set
end
local sensorHost,sensorTicker
local sensors={}
local sensorState={available=nil,reason=nil}
local spendState={plain=0,hidden=0}
function ns.PartyCooldownSensors()return sensors,sensorState end
local function Plain(v)return ns.Plain(v,"boolean")end
local function SensorRead(c)
    local ok,v=pcall(c.IsMouseOver,c,1e5,-1e5,0,0)
    if not ok then return false end
    if ns.Plain(v)then return v==true end
    return v
end

local EVAL=function()return C_CurveUtil and C_CurveUtil.EvaluateColorValueFromBoolean end
local fine
local function Fine()
    if fine~=nil then return fine end
    local eval=EVAL();if not eval then return false end
    local ok,a=pcall(eval,true,0.123456789,0);local ok2,b=pcall(eval,false,0,0.987654321)
    fine=ok and ok2 and a==0.123456789 and b==0.987654321 or false
    return fine
end
ns.PartyCooldownFine=function()fine=nil;return Fine()end
local function NewSlot(now)return{epoch=Fine()and now or math.floor(now),code=0,wepoch=math.floor(now),whole=0}end
local function MoveSlot(sl,sec)sl.epoch=sl.epoch+sec;sl.wepoch=sl.wepoch+sec end
ns.PartyCooldownMoveSlot=MoveSlot
local HiddenTrack
function HiddenTrack(m,id,now)
    m.hiddenCd=m.hiddenCd or{}
    local t=m.hiddenCd[id]
    if not t then
        local cd=math.floor(ns.PartyCooldownLength(m,id)+0.5);if cd<=0 then return nil end
        local unit=math.max(1,math.ceil(cd/100));local window=255*unit
        t={cd=cd,unit=unit,window=window,open=window-cd,cur=1,slot={NewSlot(now),NewSlot(now)}}
        m.hiddenCd[id]=t;t.created=true
    end
    local cd=math.floor(ns.PartyCooldownLength(m,id)+0.5)
    if cd~=t.cd and cd>0 then
        if cd*2<=t.window then for k=1,2 do MoveSlot(t.slot[k],cd-t.cd)end;t.cd=cd;t.open=t.window-cd
        else m.hiddenCd[id]=nil;return HiddenTrack(m,id,now)end
    end
    if InCombatLockdown and InCombatLockdown()then t.over=nil end
    local sl=t.slot[t.cur]
    if now-sl.wepoch>t.open then t.cur=3-t.cur;t.slot[t.cur]=NewSlot(now);t.moved=true end
    return t
end
ns.PartyCooldownHiddenTrack=Hidden
local function HiddenEdge(m,id,cur,prev,now,at)
    local eval=EVAL();if not eval then return false end
    local t=HiddenTrack(m,id,now);if not t then return false end
    local sl=t.slot[t.cur];at=at or now
    local whole=math.min(255,math.floor((at-sl.wepoch+t.cd)/t.unit+0.5))/255
    local code=Fine()and math.min(1,(at-sl.epoch+t.cd)/t.window)or whole
    local ok,v,w=pcall(function()return eval(cur,eval(prev,sl.code,code),sl.code),eval(cur,eval(prev,sl.whole,whole),sl.whole)end)
    if not ok then sensorState.refused=(sensorState.refused or 0)+1;return false end
    sl.code,sl.whole=v,w;sensorState.hiddenEdges=(sensorState.hiddenEdges or 0)+1
    local created=t.created;t.created=nil
    return true,created
end
ns.PartyCooldownHiddenEdge=HiddenEdge
function ns.PartyCooldownHiddenLeft(t,now)
    local best=0
    for k=1,2 do local sl=t.slot[k]
        if ns.Plain(sl.code,"number")then best=math.max(best,sl.epoch+t.window*sl.code-now)end
    end
    return math.max(0,best)
end
local columns={}
local function Column(cd)
    if columns[cd]then return columns[cd]end
    local out={}
    for r=1,cd do out[r]=r>=60 and string.format("%d:%02d",math.floor(r/60),r%60)or tostring(r)end
    columns[cd]=table.concat(out,"\n");return columns[cd]
end
local lineSteps={}
local function LineStep(font,size)
    local key=tostring(font)..size
    if lineSteps[key]then return lineSteps[key]end
    local probe=sensorHost or UIParent
    local fs=probe:CreateFontString(nil,"OVERLAY");pcall(fs.SetFont,fs,font,size,"OUTLINE");pcall(fs.SetSpacing,fs,0)
    fs:SetText("0");local one=fs.GetStringHeight and fs:GetStringHeight()
    fs:SetText("0\n0");local two=fs.GetStringHeight and fs:GetStringHeight();fs:Hide()
    local step=ns.Plain(one,"number")and ns.Plain(two,"number")and two-one or 0
    if step<=0 then step=size*1.15 end
    lineSteps[key]=step;return step
end
local function Bar(parent,r,g,b,a)
    local bar=CreateFrame("StatusBar",nil,parent)
    pcall(bar.SetStatusBarTexture,bar,"Interface\\Buttons\\WHITE8X8");pcall(bar.SetStatusBarColor,bar,r,g,b,a)
    pcall(bar.SetOrientation,bar,"VERTICAL");pcall(bar.SetMinMaxValues,bar,0,1);pcall(bar.SetValue,bar,0)
    return bar
end
local hiddenLayer
local function HiddenParts(icon)
    if icon.hidden then return icon.hidden end
    if not hiddenLayer then
        hiddenLayer=CreateFrame("Frame",nil,UIParent);hiddenLayer:SetFrameStrata("MEDIUM");hiddenLayer:SetSize(1,1);hiddenLayer:SetPoint("CENTER",UIParent,"CENTER",0,0)
    end
    local parts={win=CreateFrame("Frame",nil,icon)}
    pcall(parts.win.SetClipsChildren,parts.win,true)
    for k=1,2 do
        local p={}
        p.fill=Bar(icon,0,0,0,0.55);p.fill:SetAllPoints(icon)
        p.gate=Bar(hiddenLayer,0,0,0,0)
        p.veil=CreateFrame("Frame",nil,icon);pcall(p.veil.SetClipsChildren,p.veil,true)
        p.grey=p.veil:CreateTexture(nil,"ARTWORK");p.grey:SetAllPoints(icon);p.grey:SetTexCoord(0.07,0.93,0.07,0.93)
        pcall(p.grey.SetDesaturated,p.grey,true);p.grey:SetVertexColor(0.55,0.55,0.55)
        p.pos=Bar(hiddenLayer,0,0,0,0)
        -- Anchoring to parts.win does not make it a clipping ancestor.
        -- Keep the column inside an actual, fixed one-line viewport.
        p.viewport=CreateFrame("Frame",nil,p.veil);pcall(p.viewport.SetClipsChildren,p.viewport,true)
        p.text=CreateFrame("Frame",nil,p.viewport)
        p.column=p.text:CreateFontString(nil,"OVERLAY");p.column:SetJustifyH("CENTER")
        parts[k]=p
    end
    icon.hidden=parts;return parts
end
local function DressHidden(icon,t)
    local parts=HiddenParts(icon)
    local size=icon:GetWidth();if not ns.Plain(size,"number")or size<=0 then size=26 end
    local font=(W.Font and W.Font(true))or"Fonts\\FRIZQT__.TTF";local ts=math.max(9,math.floor(size*0.42))
    local sig=t.cd.."|"..size.."|"..ts
    if parts.sig==sig then return parts end
    local step=LineStep(font,ts);local jump=size+4
    parts.step,parts.jump,parts.sig=step,jump,sig
    parts.win:ClearAllPoints();parts.win:SetPoint("CENTER",icon,"CENTER",0,0);parts.win:SetSize(size+6,math.min(step,ts+1))
    pcall(parts.win.SetFrameLevel,parts.win,(icon:GetFrameLevel()or 0)+6)
    for k=1,2 do local p=parts[k]
        p.fill:SetFrameLevel((icon:GetFrameLevel()or 0)+3);p.veil:SetFrameLevel((icon:GetFrameLevel()or 0)+2)
        p.pos:SetSize(1,t.window*step);pcall(p.pos.SetMinMaxValues,p.pos,0,1)
        p.gate:SetSize(1,t.window*jump);pcall(p.gate.SetMinMaxValues,p.gate,0,1)
        local edge=p.gate.GetStatusBarTexture and p.gate:GetStatusBarTexture()or p.gate
        p.veil:ClearAllPoints();p.veil:SetPoint("TOP",edge,"TOP",0,0);p.veil:SetPoint("BOTTOM",edge,"TOP",0,-(t.cd+1)*jump);p.veil:SetWidth(size)
        local top=p.pos.GetStatusBarTexture and p.pos:GetStatusBarTexture()or p.pos
        pcall(p.column.SetFont,p.column,font,ts,"OUTLINE");pcall(p.column.SetSpacing,p.column,0);p.column:SetTextColor(1,1,1)
        p.column:SetText(Column(t.cd));p.column:ClearAllPoints();p.column:SetPoint("TOP",top,"TOP",0,0)
        p.viewport:ClearAllPoints();p.viewport:SetAllPoints(parts.win);pcall(p.viewport.SetFrameLevel,p.viewport,(icon:GetFrameLevel()or 0)+5)
        p.text:ClearAllPoints();p.text:SetAllPoints(p.viewport);pcall(p.text.SetFrameLevel,p.text,(icon:GetFrameLevel()or 0)+6)
        p.second=nil
    end
    return parts
end
local shownHidden={}
local function SlideHidden()
    local now=GetTime();local second=math.floor(now)
    for icon,t in pairs(shownHidden)do
        if icon.track~=t or not icon:IsVisible()then shownHidden[icon]=nil
        else
            local parts=icon.hidden
            for k=1,2 do local sl,p=t.slot[k],parts[k]
                local low=(now-sl.epoch)/t.window
                pcall(p.fill.SetMinMaxValues,p.fill,low,low+t.cd/t.window);pcall(p.fill.SetValue,p.fill,sl.code)
                pcall(p.pos.SetValue,p.pos,sl.whole);pcall(p.gate.SetValue,p.gate,sl.code)
                p.gate:ClearAllPoints();p.gate:SetPoint("BOTTOM",icon,"BOTTOM",0,-(now-sl.epoch)*parts.jump)
                if p.second~=second or p.epoch~=sl.wepoch then
                    p.second,p.epoch=second,sl.wepoch
                    p.pos:ClearAllPoints();p.pos:SetPoint("BOTTOM",parts.win,"BOTTOM",0,-(second-sl.wepoch)*parts.step)
                end
            end
        end
    end
end
ns.PartyCooldownSlideHidden=SlideHidden
function ShowHidden(icon,t)
    icon.track=t
    local parts=icon.hidden
    if not t then
        if parts then parts.win:Hide();for k=1,2 do parts[k].fill:Hide();parts[k].veil:Hide();parts[k].pos:Hide();parts[k].gate:Hide()end end
        shownHidden[icon]=nil;return
    end
    parts=DressHidden(icon,t)
    local tex=icon.spellID and W.SpellTexture(icon.spellID)
    parts.win:Show();for k=1,2 do parts[k].grey:SetTexture(tex);parts[k].fill:Show();parts[k].veil:Show();parts[k].pos:Show();parts[k].gate:Show();parts[k].second=nil end
    shownHidden[icon]=t
end
ns.PartyCooldownShowHidden=ShowHidden
function ns.PartyCooldownReport()
    local lines={}
    lines[#lines+1]="Party cooldowns "..tostring(ns.version)..", in combat: "..tostring(InCombatLockdown and InCombatLockdown()or false)..". Buff sensors: "..(sensorState.available==false and("not available ("..tostring(sensorState.reason)..")")or(#sensors.." watching"))
        ..", lit now "..(function()local n=0;for _,s in ipairs(sensors)do if s.lit then n=n+1 end end;return n end)()
        ..", hidden answers kept "..(sensorState.hiddenEdges or 0)..", power bars read "..spendState.plain.." hidden "..spendState.hidden..", exact times "..tostring(ns.PartyCooldownFine and ns.PartyCooldownFine()or false)..", refused "..(sensorState.refused or 0)..(EVAL()and""or", no curve helper")..", my cooldowns "..shareState
    local k=ns.PartyCooldownKickStats and ns.PartyCooldownKickStats()
    if k then lines[#lines+1]="Interrupts seen "..k.seen..": by the meter "..k.meter..", by name "..k.named..", only one ready "..k.ready..", unknown "..k.unsure end
    for _,name in ipairs(order)do local m=members[name]
        local sens=0;for _,s in ipairs(sensors)do if s.member==name then sens=sens+1 end end
        lines[#lines+1]=name..": "..tostring(m.class).." "..tostring(m.spec and ns.Catalog.specs[m.spec]or"spec unknown")..(m.talented and", talents read"or", talents not read")
            ..", icons "..#ns.PartyCooldownList(m)..", sensors "..sens..", casts seen "..(m.seen or 0).." hidden "..(m.hidden or 0).." by buff "..(m.sensed or 0)
            ..", hidden timers "..(function()local n=0;for _ in pairs(m.hiddenCd or{})do n=n+1 end;return n end)()
            ..(m.ranks and", cooldown talents read"or"")
            ..(m.addon and(", lengths sent "..math.floor(GetTime()-(m.sentAt or GetTime())).." s ago")or", base lengths")
            ..(function()
                local exact,guess,from=0,0,{}
                for id in pairs(m.used)do if ns.PartyCooldownLeft(m,id)>0 then
                    if ns.PartyCooldownExact(m,id)then exact=exact+1 else guess=guess+1 end
                    local how=m.how and m.how[id]or"?";from[how]=(from[how]or 0)+1
                end end
                local list={};for how,n in pairs(from)do list[#list+1]=how.." "..n end;table.sort(list)
                return exact+guess>0 and(", running "..exact.." exact "..guess.." estimated ("..table.concat(list,", ")..")")or""
            end)()
    end
    return lines
end
local function NewSensor(unit,buffs,filter)
    if not sensorHost then sensorHost=CreateFrame("Frame",nil,UIParent);sensorHost:SetSize(1,1);sensorHost:SetPoint("TOPLEFT",UIParent,"TOPLEFT",-20,0)end
    local ok,c=pcall(CreateFrame,"AuraContainer",nil,sensorHost,"CustomAuraContainerTemplate")
    if not ok or not c or not c.AddAuraGroup then sensorState.available=false;sensorState.reason="the game has no aura container widget";return nil end
    c:SetSize(1,1);c:ClearAllPoints();c:SetPoint("TOPLEFT",UIParent,"TOPLEFT",-11,0);pcall(c.EnableMouse,c,false)
    local added=pcall(c.AddAuraGroup,c,"pcd",filter or"HELPFUL",{maxFrameCount=1,candidateFilters={includeSpellIDs=buffs},
        initializeFrame=function(b)pcall(b.SetSize,b,1,1);pcall(b.SetMouseClickEnabled,b,false);pcall(b.SetMouseMotionEnabled,b,false)end,
        layout={elementWidth=50000,elementHeight=1,elementSpacing=0,lineSpacing=0}})
    if not added then sensorState.available=false;sensorState.reason="the aura container refused a buff group";return nil end
    sensorState.available=true
    return c
end
local function ExternalOwner(id)
    local best
    for _,m in pairs(members)do
        -- Count every possible caster, including self and members already on cooldown.
        -- Otherwise the same group aura can successively consume everyone's timer.
        for _,x in ipairs(ns.PartyCooldownList(m))do if x==id then
            if best and best~=m then return nil end;best=m
        end end
    end
    return best
end
local function Sensed(m,id,at)
    if not m or not ns.PartyCooldownTracked(id,m.spec)then return end
    local last=m.used[id]
    if last and GetTime()-last<ns.PartyCooldownLength(m,id)-1 and not(MaxCharges(m,id)>1 and GetTime()-last>1)then return end
    Started(m,id,at or GetTime(),"sensor");m.sensed=(m.sensed or 0)+1
    ns.DrawPartyCooldowns();RedrawLater(ns.PartyCooldownLength(m,id))
end
local auraAt={}
local function PollSensors(only)
    local now,redraw=GetTime(),false
    local owners={}
    for _,s in ipairs(sensors)do if not only or only[s.unit]then
        local v=SensorRead(s.frame)
        local at=auraAt[s.unit];if not at or now-at>0.5 or at>now then at=now end
        at=at-(LAG[s.spell]or 0)
        if s.hold and now<s.hold then s.prev=v;s.lit=Plain(v)and v
        else
            local shared=s.kind==EXTERNAL or s.kind==ENEMY
            local m
            if shared then
                if owners[s.spell]==nil then owners[s.spell]=ExternalOwner(s.spell)or false end
                m=owners[s.spell]or nil
            else m=members[s.member]end
            local running=m and ns.PartyCooldownLeft(m,s.spell)>0
            if running then
            elseif Plain(v)and Plain(s.prev)then
                if v and not s.prev then
                    Sensed(m,s.spell,at)
                end
            elseif m and ns.PartyCooldownTracked(s.spell,m.spec)then
                local _,created=HiddenEdge(m,s.spell,v,s.prev,now,at);if created then redraw=true end
            end
            s.prev=v;s.lit=Plain(v)and v
        end
    end end
    if redraw then ns.DrawPartyCooldowns()end
end
ns.PartyCooldownPollSensors=function()PollSensors();SlideHidden()end
local POLL=1
local driver=CreateFrame("Frame");local quick,lastRead,dirty=0,0,{}
local sensorUnits={}
driver:SetScript("OnUpdate",function()
    local now=GetTime()
    if #sensors>0 and now-lastRead>=POLL then quick=0;dirty={};lastRead=now;Timed("sensor poll",PollSensors)
    elseif quick>0 then quick=quick-1;Timed("sensor quick reads",PollSensors,dirty);if quick==0 then dirty={}end end
    if next(shownHidden)then SlideHidden()end
end)
function ns.PartyCooldownAura(unit)
    if not ns.Plain(unit,"string")then return end
    if sensorUnits[unit]then auraAt[unit]=GetTime();dirty[unit]=true;quick=3 end
end
function ns.PartyCooldownPlate(unit)
    if not(ns.Plain(unit,"string")and sensorUnits[unit])then return end
    local hold=GetTime()+0.4
    for _,s in ipairs(sensors)do if s.unit==unit then s.hold=hold end end
end
local pools={HELPFUL={},HARMFUL={}}
local Rebuild,sensorSig -- the rebuild itself and the sensors it last made, defined below
function ns.PartyCooldownSensorCount()return #sensors end
function ns.RebuildPartyCooldownSensors()
    local cfg=ns.PartyCooldownConfig()
    if cfg.enabled and cfg.sensors and ns.PartyCooldownsLoaded()and InCombatLockdown and InCombatLockdown()then return #sensors end
    return Timed("sensor rebuild",Rebuild,cfg)
end
local function Signature(list)
    local parts={}
    for _,s in ipairs(list)do parts[#parts+1]=s.unit..":"..s.spell..":"..s.kind..":"..tostring(s.member)..":"..tostring(s.owner and s.owner.name)end
    return table.concat(parts,",")
end
Rebuild=function(cfg)
    local want={}
    local others=false;for _,name in ipairs(order)do if members[name]and not members[name].me then others=true end end
    local on=cfg.enabled and cfg.sensors and ns.PartyCooldownsLoaded()and sensorState.available~=false and others
    if on then
        local externals,externalOwners,stops,stopOwners={},{},{},{}
        for _,name in ipairs(order)do local m=members[name]
            for _,id in ipairs(ns.PartyCooldownList(m))do local kind,buffs=BuffsOf(id)
                if kind==EXTERNAL then externals[id]=buffs;if externalOwners[id]==nil then externalOwners[id]=m else externalOwners[id]=false end
                elseif kind==ENEMY then stops[id]=buffs;if stopOwners[id]==nil then stopOwners[id]=m else stopOwners[id]=false end
                elseif KIND[id]=="kick"then
                elseif not m.me then want[#want+1]={unit=m.unit,member=name,spell=id,buff=buffs,kind=SELF}end
            end
        end
        local ext={};for id in pairs(externals)do ext[#ext+1]=id end;table.sort(ext)
        for _,name in ipairs(order)do local m=members[name]
            for _,id in ipairs(ext)do want[#want+1]={unit=m.unit,member=name,spell=id,buff=externals[id],kind=EXTERNAL,owner=externalOwners[id]or nil}end
        end
        local st={};for id in pairs(stops)do st[#st+1]=id end;table.sort(st)
        for _,id in ipairs(st)do
            for i=1,SENSE_PLATES do want[#want+1]={unit="nameplate"..i,spell=id,buff=stops[id],kind=ENEMY,owner=stopOwners[id]or nil,filter="HARMFUL"}end
        end
    end
    local sig=Signature(want)
    if sig==sensorSig and #sensors==#want then
        for k,s in ipairs(sensors)do s.owner=want[k].owner end
        return #sensors
    end
    for _,s in ipairs(sensors)do pcall(s.frame.SetEnabled,s.frame,false);s.frame:Hide();local p=pools[s.filter];p[#p+1]=s.frame end
    sensors={};sensorUnits={};sensorSig=nil
    if sensorTicker then sensorTicker:Cancel();sensorTicker=nil end
    if not on then return 0 end
    local made={}
    for _,s in ipairs(want)do
        s.filter=s.filter or"HELPFUL"
        local c=table.remove(pools[s.filter])
        if c then pcall(c.SetAuraGroupCandidateFilters,c,"pcd",{includeSpellIDs=s.buff});c:Show()
        else c=NewSensor(s.unit,s.buff,s.filter)end
        if not c then break end
        sensorUnits[s.unit]=true
        pcall(c.SetUnit,c,s.unit);pcall(c.SetEnabled,c,true);pcall(c.UpdateAllAuras,c)
        s.frame=c;s.prev=SensorRead(c);s.lit=Plain(s.prev)and s.prev;s.hold=GetTime()+0.6;made[#made+1]=s
    end
    sensors=made;if #made==#want then sensorSig=sig end
    return #sensors
end

local function Shorten(m,id,sec)
    local start=m.used[id]
    if start and GetTime()<start+ns.PartyCooldownLength(m,id)then m.used[id]=start-sec;m.shortened=true;m.cut=m.cut or{};m.cut[id]=true end
    local t=m.hiddenCd and m.hiddenCd[id]
    if t then for k=1,2 do MoveSlot(t.slot[k],-sec)end end
end
ns.PartyCooldownShorten=Shorten
local lastSpendDraw=0
function ns.PartyCooldownPower(unit)
    for _,m in pairs(members)do
        local sp=m.class and SPEND[m.class]
        if sp and m.unit==unit and m.ranks and(m.ranks[sp.talent]or 0)>0 and sp.per[m.spec or 0]then
            local ok,power=pcall(UnitPower,unit,sp.power)
            if ok and ns.Plain(power,"number")then
                spendState.plain=spendState.plain+1
                local fighting=UnitAffectingCombat and UnitAffectingCombat(unit)
                if m.power and power<m.power and ns.Plain(fighting,"boolean")and fighting then
                    m.spent=(m.spent or 0)+m.power-power
                    local per=sp.per[m.spec]
                    while m.spent>=per do
                        m.spent=m.spent-per
                        for _,id in ipairs(sp.spells[m.spec]or{})do Shorten(m,id,sp.sec or 1)end
                    end
                end
                m.power=power
            else spendState.hidden=spendState.hidden+1;m.power=nil end
            if m.shortened and GetTime()-lastSpendDraw>1 then m.shortened=nil;lastSpendDraw=GetTime();ns.DrawPartyCooldowns()end
        end
    end
end
local kickState={seen=0,meter=0,named=0,ready=0,unsure=0}
local meterOrder,lastKickAt,ownKickAt,lastKick=nil,0,0,{}
local ownUnsureAt=-100 -- the last cast of yours the game hid
local function OwnPetKick()
    for id in pairs(PET_KICK)do if Known(id)then return true end end
    return false
end
ns.PartyCooldownOwnPetKick=OwnPetKick
local function KickOf(m)
    for _,id in ipairs(ns.PartyCooldownList(m))do if KIND[id]=="kick"then return id end end
end
local function Kicked(m,at,how,unit)
    lastKickAt=GetTime()
    if not m or m.me then return false end
    local id=KickOf(m);if not id then return false end
    if lastKick[m.name]and math.abs(at-lastKick[m.name])<1 then return true end
    lastKick[m.name]=at;kickState[how]=kickState[how]+1
    Started(m,id,at,how,MarkOf(unit));ns.DrawPartyCooldowns();RedrawLater(ns.PartyCooldownLength(m,id))
    return true
end
local specIcons={}
local function SpecIcon(spec)
    if specIcons[spec]==nil then
        local get=(C_SpecializationInfo and C_SpecializationInfo.GetSpecializationInfoByID)or GetSpecializationInfoByID
        local ok,_,_,_,icon=pcall(get or error,spec);specIcons[spec]=ok and ns.Plain(icon,"number")and icon or false
    end
    return specIcons[spec]or nil
end
local function MeterList()
    local DM,E=C_DamageMeter,Enum
    if not(DM and DM.GetCombatSessionFromType and E and E.DamageMeterType and E.DamageMeterType.Interrupts and E.DamageMeterSessionType)then return nil end
    local ok,session=pcall(DM.GetCombatSessionFromType,E.DamageMeterSessionType.Current,E.DamageMeterType.Interrupts)
    if not ok or not ns.Plain(session,"table")or not ns.Plain(session.combatSources,"table")then return nil end
    local list,count={},{}
    for _,src in ipairs(session.combatSources)do if ns.Plain(src,"table")then
        local name,class,icon=src.name,src.classFilename,src.specIconID
        name=ns.Plain(name,"string")and name~=""and name or nil
        class=ns.Plain(class,"string")and class~=""and class or nil
        icon=ns.Plain(icon,"number")and icon or nil
        if name or class then
            local key=name or(class..":"..tostring(icon));count[key]=(count[key]or 0)+1
            list[#list+1]={key=key..(count[key]>1 and("#"..count[key])or""),name=name,class=class,icon=icon}
        end
    end end
    return list
end
local function Find(name)
    local m=members[ns.FullName(name)or""];if m or name:find("-",1,true)then return m end
    local found;for _,x in pairs(members)do if x.name:match("^[^%-]+")==name then if found then return nil end;found=x end end
    return found
end
ns.PartyCooldownFind=Find
local function MemberOf(e)
    if e.name then return Find(e.name)end
    local found
    for _,m in pairs(members)do
        if m.class==e.class and not(e.icon and m.spec and SpecIcon(m.spec)and SpecIcon(m.spec)~=e.icon)then if found then return nil end;found=m end
    end
    return found
end
function ns.PartyCooldownMeter(base)
    local list=MeterList();local old=meterOrder;meterOrder=list
    if base or not(list and old)then return nil end
    local was={};for i,e in ipairs(old)do was[e.key]=i end
    local who,n=nil,0
    for i,e in ipairs(list)do local o=was[e.key];if not o or i<o then who=e;n=n+1 end end
    if n~=1 then return nil end
    local m=MemberOf(who);if m then Kicked(m,GetTime(),"meter")end
    return m
end
local ENEMY_UNIT={"^nameplate%d","^target$","^focus$","^boss%d"}
function ns.PartyCooldownInterrupted(unit,by)
    if not ns.Plain(unit,"string")then return end
    local enemy=false;for _,p in ipairs(ENEMY_UNIT)do if unit:match(p)then enemy=true end end
    if not enemy then return end
    local ok,hostile=pcall(UnitCanAttack or error,"player",unit);if ok and ns.Plain(hostile,"boolean")and not hostile then return end
    if ns.KickRotationInterrupt then ns.KickRotationInterrupt(unit)end
    local now=GetTime();kickState.seen=kickState.seen+1
    if ns.Plain(by,"string")and by~=""then
        for _,m in pairs(members)do
            local pet=m.me and"pet"or(m.unit or""):gsub("^(%a+)(%d+)$","%1pet%2")
            for _,u in ipairs({m.unit,pet})do local okG,guid=pcall(UnitGUID or error,u);if okG and guid==by then Kicked(m,now,"named",unit);return end end
        end
        return
    end
    if now-ownKickAt<0.6 then lastKickAt=now;return end
    local mine=now-ownUnsureAt<0.6
    local function decide()
        if lastKickAt>=now-0.05 then return end
        if math.abs(ownKickAt-now)<0.6 then lastKickAt=now;return end
        if mine or math.abs(ownUnsureAt-now)<0.6 then kickState.unsure=kickState.unsure+1;return end
        local only
        for _,m in pairs(members)do
            local id=not m.me and KickOf(m)
            if id and ns.PartyCooldownLeft(m,id)<=0 then if only then kickState.unsure=kickState.unsure+1;return end;only=m end
        end
        if only then Kicked(only,now,"ready",unit)else kickState.unsure=kickState.unsure+1 end
    end
    if C_Timer and C_Timer.After then C_Timer.After(0.4,decide)else decide()end
end
function ns.PartyCooldownKickStats()return kickState end

local ownDraw
local events=CreateFrame("Frame")
local function Listen(on)
    for _,e in ipairs({"UNIT_SPELLCAST_SUCCEEDED","GROUP_ROSTER_UPDATE","PLAYER_SPECIALIZATION_CHANGED","TRAIT_CONFIG_UPDATED","INSPECT_READY",
        "READY_CHECK","PLAYER_REGEN_ENABLED","ENCOUNTER_END","CHALLENGE_MODE_START","PLAYER_ENTERING_WORLD","UNIT_POWER_UPDATE","SPELL_UPDATE_COOLDOWN","UNIT_AURA",
        "UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_CHANNEL_STOP","DAMAGE_METER_COMBAT_SESSION_UPDATED","DAMAGE_METER_CURRENT_SESSION_UPDATED","DAMAGE_METER_RESET",
        "PLAYER_REGEN_DISABLED","NAME_PLATE_UNIT_ADDED","NAME_PLATE_UNIT_REMOVED"})do
        if on then pcall(events.RegisterEvent,events,e)elseif events.UnregisterEvent then events:UnregisterEvent(e)end
    end
end
function ns.RefreshPartyCooldowns()
    local cfg=ns.PartyCooldownConfig();LoadCustom();Listen(cfg.enabled==true)
    if cfg.enabled then ns.PartyCooldownRoster();ReadOwnTalents();QueueInspect();ns.SharePartyCooldowns()end
    ns.RebuildPartyCooldownSensors()
    if ns.RefreshPartyExtras then ns.RefreshPartyExtras()end
    return ns.DrawPartyCooldowns()
end
events:SetScript("OnEvent",function(_,event,a,_,c,d)
    if event=="UNIT_SPELLCAST_SUCCEEDED"then
        if a=="player"or a=="pet"then
            if not ns.Plain(c,"number")then if a=="player"or OwnPetKick()then ownUnsureAt=GetTime()end
            elseif KIND[ALIAS[c]or c]=="kick"then ownKickAt=GetTime()end
        end
        if ns.Plain(a,"string")and(a=="player"or a=="pet"or a=="target"or a=="focus"or a:match("^party%d")or a:match("^raid%d")or a:match("^partypet%d")or a:match("^raidpet%d")or a:match("^nameplate%d"))then ns.PartyCooldownCast(a,c)end
    elseif event=="UNIT_SPELLCAST_INTERRUPTED"then ns.PartyCooldownInterrupted(a,d)
    elseif event=="UNIT_SPELLCAST_CHANNEL_STOP"then
        if d~=nil and not(ns.Plain(d)and(type(d)~="string"or d==""))then ns.PartyCooldownInterrupted(a,d)end
    elseif event=="DAMAGE_METER_COMBAT_SESSION_UPDATED"then
        if ns.Plain(a,"number")and Enum and Enum.DamageMeterType and a==Enum.DamageMeterType.Interrupts then ns.PartyCooldownMeter()end
    elseif event=="DAMAGE_METER_CURRENT_SESSION_UPDATED"or event=="DAMAGE_METER_RESET"or event=="PLAYER_REGEN_DISABLED"then ns.PartyCooldownMeter(true)
    elseif event=="NAME_PLATE_UNIT_ADDED"or event=="NAME_PLATE_UNIT_REMOVED"then ns.PartyCooldownPlate(a)
    elseif event=="UNIT_AURA"then ns.PartyCooldownAura(a)
    elseif event=="UNIT_POWER_UPDATE"then
        if ns.Plain(a,"string")then ns.PartyCooldownPower(a)end
    elseif event=="SPELL_UPDATE_COOLDOWN"then
        if next(pendingLearn)then LearnPending()end
        if not ownDraw and C_Timer and C_Timer.NewTimer then ownDraw=C_Timer.NewTimer(0.2,function()ownDraw=nil;ns.DrawPartyCooldowns()end)end
    elseif event=="PLAYER_REGEN_ENABLED"then
        for _,m in pairs(members)do m.hiddenCast=nil end
        LearnPending()
        local longest=0
        for _,m in pairs(members)do for _,t in pairs(m.hiddenCd or{})do t.over=t.over or GetTime()+t.cd;longest=math.max(longest,t.cd)end end
        if longest>0 then RedrawLater(longest)end
        ns.SharePartyCooldowns();QueueInspect();ns.RebuildPartyCooldownSensors();ns.DrawPartyCooldowns()
    elseif event=="CHALLENGE_MODE_START"then ns.PartyCooldownReset()
    elseif event=="ENCOUNTER_END"then
        if IsInRaid and IsInRaid()then ns.PartyCooldownReset()end
    elseif event=="INSPECT_READY"then
        ns.PartyCooldownRoster()
        for _,m in pairs(members)do
            if not m.me and UnitGUID and ns.Plain(a,"string")then local ok,guid=pcall(UnitGUID,m.unit);if ok and guid==a then ReadTalents(m)end end
        end
        QueueInspect();ns.RebuildPartyCooldownSensors();ns.DrawPartyCooldowns()
    else
        if event~="READY_CHECK"then ns.PartyCooldownRoster()end
        if event=="GROUP_ROSTER_UPDATE"or event=="PLAYER_ENTERING_WORLD"then QueueInspect()end
        if event=="PLAYER_ENTERING_WORLD"then ns.PartyCooldownForgetFrames()end
        if event=="PLAYER_SPECIALIZATION_CHANGED"and ns.Plain(a,"string")then for _,m in pairs(members)do if m.unit==a and not m.me then if m.guid then inspected[m.guid]=nil end;m.asked=nil;m.tries=nil;m.far=nil;m.talented=nil;m.ranks=nil;m.spec=nil;m.sentSpec=nil;m.known=nil;m.cds=nil;Prune(m,nil)
            for id in pairs(m.used)do local info=byID[id];if info and info.specs then m.used[id]=nil end end end end;QueueInspect()end
        if event=="PLAYER_SPECIALIZATION_CHANGED"and a=="player"then for _,m in pairs(members)do if m.me then Prune(m,ns.Spec())end end end
        if event=="TRAIT_CONFIG_UPDATED"or event=="PLAYER_SPECIALIZATION_CHANGED"and a=="player"then ReadOwnTalents()end
        if event~="READY_CHECK"then ns.RebuildPartyCooldownSensors()end
        ns.SharePartyCooldowns();ns.DrawPartyCooldowns()
    end
end)
local login=CreateFrame("Frame");login:RegisterEvent("PLAYER_LOGIN");login:SetScript("OnEvent",function()ns.RefreshPartyCooldowns()end)

local CLASSES={"DEATHKNIGHT","DEMONHUNTER","DRUID","EVOKER","HUNTER","MAGE","MONK","PALADIN","PRIEST","ROGUE","SHAMAN","WARLOCK","WARRIOR"}
local CLASS_NAMES={DEATHKNIGHT="Death Knight",DEMONHUNTER="Demon Hunter",DRUID="Druid",EVOKER="Evoker",HUNTER="Hunter",MAGE="Mage",MONK="Monk",PALADIN="Paladin",PRIEST="Priest",ROGUE="Rogue",SHAMAN="Shaman",WARLOCK="Warlock",WARRIOR="Warrior"}
local function SpellName(id)
    local ok,info=pcall(C_Spell and C_Spell.GetSpellInfo or function()end,id)
    return ok and type(info)=="table"and ns.Plain(info.name,"string")and info.name or(ns.Catalog.spellNames[id]or("Spell "..id))
end
local DrawAnchors
local function DrawAbilities(parent,d)
    local cfg=ns.PartyCooldownConfig();LoadCustom()
    if not d.class then local _,mine=UnitClass("player");d.class=SPELLS[mine]and mine or"DEATHKNIGHT"end
    local left=W.Card(parent,0,56,200,536,L("Class"))
    for i,class in ipairs(CLASSES)do
        W.Button(left,L(CLASS_NAMES[class]),10,30+(i-1)*36,180,function()d.class=class;kit.refresh()end,d.class==class,"pcd-class:"..class,{h=32})
    end
    local right=W.Card(parent,212,56,708,536,L(CLASS_NAMES[d.class]))
    local specs=ns.ClassSpecs[d.class]or{}
    d.specs=d.specs or{};local spec=d.specs[d.class]or specs[1];d.specs[d.class]=spec
    local tabs={};for _,sp in ipairs(specs)do tabs[#tabs+1]={value=sp,label=L((ns.Catalog.specs[sp]or tostring(sp)):gsub(" "..CLASS_NAMES[d.class].."$",""))}end
    W.Segmented(right,tabs,spec,12,30,684,function(v)d.specs[d.class]=v;kit.refresh()end,"pcd-spec")
    local ids=ns.PartyCooldownSpecSpells(d.class,spec)
    local list=W.Scroll(right,12,70,684,368,"pcd:spells",C.background);local y=4
    for _,id in ipairs(ids)do
        local info=byID[id]or{};local on=ns.PartyCooldownTracked(id,spec)
        local row=W.Panel(list,0,y,656,36,C.raised,C.clear,6)
        W.Icon(row,id,6,4,28)
        W.Toggle(row,SpellName(id),on,42,4,300,function(v)ns.SetPartyCooldownTracked(id,v,spec);kit.refresh()end,"pcd-spell:"..id)
        W.Label(row,info.added and L("Added by you")or info.detected and L("Seen in game")or(info.specs and L("This spec")or L("Every spec of the class")),350,12,146,11,C.muted):SetWordWrap(false)
        W.Label(row,math.floor(BaseCooldown(id)+0.5).." s",500,12,50,11,C.soft)
        W.Button(row,"",556,5,26,function()ns.MovePartyCooldown(d.class,spec,id,-1);kit.refresh()end,false,"pcd-up:"..id,{h=26,kind="ghost",glyph="up",tooltip=L("Move up")})
        W.Button(row,"",586,5,26,function()ns.MovePartyCooldown(d.class,spec,id,1);kit.refresh()end,false,"pcd-down:"..id,{h=26,kind="ghost",glyph="chevron",tooltip=L("Move down")})
        if info.added then W.Button(row,"",620,5,26,function()kit.done(ns.RemovePartyCooldownSpell(d.class,id),nil,L("Spell removed"))end,false,"pcd-del:"..id,{h=26,kind="danger",glyph="trash",tooltip=L("Remove")})end
        y=y+40
    end;list:SetHeight(math.max(1,y))
    local field=W.Field(right,L("ADD A SPELL BY ID"),d.newSpell or"",12,450,200,"pcd:newSpell")
    W.OnText(field,function(self)d.newSpell=self:GetText()end)
    W.Button(right,L("Add"),220,466,100,function()local text=ns.UIControls["pcd:newSpell"]:GetText();local ok,err=ns.AddPartyCooldownSpell(d.class,text);if ok then d.newSpell=""else d.newSpell=text end;kit.done(ok,err,L("Spell added"))end,false,"pcd-add",{kind="primary",align="CENTER"})
    W.Button(right,L("All on"),336,466,100,function()for _,id in ipairs(ids)do ns.SetPartyCooldownTracked(id,true,spec)end;kit.refresh()end,false,"pcd-allon",{kind="outline",align="CENTER"})
    W.Button(right,L("All off"),444,466,100,function()for _,id in ipairs(ids)do ns.SetPartyCooldownTracked(id,false,spec)end;kit.refresh()end,false,"pcd-alloff",{kind="outline",align="CENTER"})
    W.Label(right,L("The cooldowns tracked for this spec. Off: not shown and not timed for players of this spec. Lengths are the game's base cooldowns."),12,506,684,11,C.muted)
end
local ANCHOR_HELP={
    kick="An interrupt is credited by the game's interrupt meter, by the interrupter's name when the game gives it, or to the only member whose interrupt is ready. A kick that misses the cast cannot be seen.",
    cc="Fears, disorients, knockbacks and grips are seen as their debuff on enemy nameplates, so enemy nameplates must be shown.",
    stun="Stuns are seen as their debuff on enemy nameplates, so enemy nameplates must be shown. Hammer of Justice is shown only for yourself, because Fist of Justice shortens it.",
    move="Group movement cooldowns: Stampeding Roar, Wind Rush Totem, Blessing of Freedom, Tiger's Lust and Time Spiral.",
    potion="Combat potions share one cooldown of 5 minutes, whatever potion was drunk. Seen from the cast, or from the potion's buff when the game hides the cast.",
}
local PAIRS={{"kick","cc"},{"stun","move"},{"potion","main"},{"style"}}
local DrawMainCard
function DrawAnchors(parent,apply,d)
    local cfg=ns.PartyCooldownConfig()
    local function list(values,suffix)local out={};for _,v in ipairs(values)do out[#out+1]={value=v,label=v..(suffix or"")}end;return out end
    local sizes,widths,counts=list({16,18,20,22,24,26,30,36,42,48}," px"),list({120,150,180,200,240,280,320}," px"),list({1,2,3,4,5,6,7,8,9,10})
    d.pair=d.pair or 1
    local tabs={};for i,p in ipairs(PAIRS)do
        tabs[#tabs+1]={value=i,label=p[1]=="style"and L("Look")or L(TITLES[p[1]]).." · "..L(p[2]=="main"and"Main list"or TITLES[p[2]])}end
    W.Segmented(parent,tabs,d.pair,0,56,920,function(v)d.pair=v;kit.refresh()end,"pcd-pair")
    for i,key in ipairs(PAIRS[d.pair]or PAIRS[1])do if key=="style"then Style.Card(parent,apply,d)elseif key=="main"then DrawMainCard(parent,(i-1)*466,apply)else
        local a=cfg.anchors[key];local field=FIELD[key];local id="pcd-"..key..":"
        local bars=a.style=="bars"
        local card=W.Card(parent,(i-1)*466,96,454,462,L(TITLES[key]))
        W.Toggle(card,L("Show"),cfg[field]~=false,12,34,430,function(v)cfg[field]=v;apply()end,"pcd:"..field)
        W.Select(card,L("STYLE"),{{value="icons",label=L("Icons")},{value="bars",label=L("Bars")}},bars and"bars"or"icons",12,70,207,function(v)a.style=v;apply()end,id.."style")
        W.Select(card,bars and L("BAR HEIGHT")or L("ICON SIZE"),sizes,tonumber(a.size)or 30,235,70,207,function(v)a.size=v;apply()end,id.."size")
        W.Select(card,L("HORIZONTAL"),{{value="RIGHT",label=L("To the right")},{value="LEFT",label=L("To the left")}},a.dir or"RIGHT",12,126,207,function(v)a.dir=v;apply()end,id.."dir")
        W.Select(card,L("VERTICAL"),{{value="DOWN",label=L("Down")},{value="UP",label=L("Up")}},a.grow or"DOWN",235,126,207,function(v)a.grow=v;apply()end,id.."grow")
        W.Select(card,L("PER ROW"),counts,tonumber(a.perRow)or 1,12,182,207,function(v)a.perRow=v;apply()end,id.."perRow")
        W.Select(card,L("ROWS"),counts,tonumber(a.rows)or 5,235,182,207,function(v)a.rows=v;apply()end,id.."rows")
        if bars then
            W.Select(card,L("BAR WIDTH"),widths,tonumber(a.width)or 180,12,238,207,function(v)a.width=v;apply()end,id.."width")
            W.Select(card,L("BAR TEXTURE"),ns.PartyBarTextures(),a.texture or"",235,238,207,function(v)a.texture=v;apply()end,id.."texture")
        end
        W.Toggle(card,L("Names"),a.names,12,300,207,function(v)a.names=v;apply()end,id.."names")
        W.Toggle(card,L("Only in use"),a.hideReady,235,300,207,function(v)a.hideReady=v;apply()end,id.."hideReady")
        W.Toggle(card,L("Include my own cooldowns"),a.self~=false,12,328,207,function(v)a.self=v;apply()end,id.."self")
        W.Toggle(card,L("Hide in raids"),a.hideInRaid,235,328,207,function(v)a.hideInRaid=v;apply()end,id.."hideInRaid")
        if key=="kick"then
            W.Toggle(card,L("Target marker"),a.mark,12,356,207,function(v)a.mark=v;apply()end,id.."mark")
            W.Toggle(card,L("Dark bars"),a.dark,235,356,207,function(v)a.dark=v;apply()end,id.."dark")
        end
        W.Button(card,L("Reset position"),12,388,430,function()local def=defaults.anchors[key];a.x,a.y=def.x,def.y;apply()end,false,id.."reset",{kind="outline",align="CENTER"})
        W.Label(card,L(ANCHOR_HELP[key]),12,424,430,11,C.muted)
    end end
    W.Button(parent,cfg.unlocked and L("Lock")or L("Unlock and preview"),0,568,454,function()cfg.unlocked=not cfg.unlocked;apply()end,false,"pcd-unlock",{kind="outline",align="CENTER"})
    W.Label(parent,L("Unlock shows every list with its name; drag them where you want them."),466,576,454,11,C.muted)
end
function Style.Card(parent,apply,d)
    local key=d.styleKey or"main"
    local wins={};for _,k in ipairs(Style.keys)do wins[#wins+1]={value=k,label=L(k=="main"and"Main list"or TITLES[k])}end
    local st,saved=ns.PartyStyle(key)
    local function set(field)return function(v)saved[field]=v;apply()end end
    local function list(values,fmt)local out={};for _,v in ipairs(values)do out[#out+1]={value=v,label=fmt and fmt(v)or tostring(v)}end;return out end
    local px=function(v)return v.." px"end
    local card=W.Card(parent,0,96,920,462,L("Look of each window"))
    W.Select(card,L("WINDOW"),wins,key,12,34,290,function(v)d.styleKey=v;kit.refresh()end,"pcd-style:window")
    local id="pcd-style:"
    W.Select(card,L("SHORT LAST ROW"),{{value="LEFT",label=L("Left")},{value="CENTER",label=L("Centre")},{value="RIGHT",label=L("Right")}},st.align,12,96,290,set("align"),id.."align")
    W.Select(card,L("SPACING"),list({0,1,2,3,4,6,8,10,14},px),st.gap,315,96,290,set("gap"),id.."gap")
    W.Select(card,L("OPACITY"),list({100,90,80,70,60,50,40,30},function(v)return v.."%"end),st.alpha,618,96,290,set("alpha"),id.."alpha")
    local numbers=list({10,11,12,13,14,16,18,20,24},px);table.insert(numbers,1,{value=0,label=L("Game default")})
    W.Select(card,L("TIMER NUMBERS"),numbers,st.numbers,12,152,290,set("numbers"),id.."numbers")
    local names=list({8,9,10,11,12,13,14,16},px);table.insert(names,1,{value=0,label=L("Default")})
    W.Select(card,L("NAME SIZE"),names,st.nameSize,315,152,290,set("nameSize"),id.."nameSize")
    W.Select(card,L("BORDER"),{{value="none",label=L("None")},{value="thin",label=L("Thin")},{value="thick",label=L("Thick")}},st.border,618,152,290,set("border"),id.."border")
    W.Select(card,L("ICON ZOOM"),{{value="normal",label=L("Normal")},{value="zoom",label=L("Zoomed in")},{value="full",label=L("Whole icon")}},st.zoom,12,208,290,set("zoom"),id.."zoom")
    if key=="main"then
        local offs=list({-20,-15,-10,-6,-4,-2,0,2,4,6,10,15,20},px)
        W.Select(card,L("OFFSET FROM THE FRAME X"),offs,st.offX,315,208,290,set("offX"),id.."offX")
        W.Select(card,L("OFFSET FROM THE FRAME Y"),offs,st.offY,618,208,290,set("offY"),id.."offY")
    end
    W.Button(card,L("Reset the look"),12,272,290,function()ns.PartyCooldownConfig().styles[key]={};apply()end,false,id.."reset",{kind="outline",align="CENTER"})
    W.Label(card,L("Every window has the same look settings: pick a window, then set where a short last row sits, the space between icons, opacity, the size of the timer numbers and names, a border and the icon zoom. Icons beside party frames use the main list's look and can be moved away from the frame."),12,316,896,11,C.muted)
end
function DrawMainCard(parent,x,apply)
    local cfg=ns.PartyCooldownConfig()
    local card=W.Card(parent,x,96,454,462,L("Main list"))
    local per={{value=0,label=L("One row")}};for _,n in ipairs({3,4,5,6,8})do per[#per+1]={value=n,label=tostring(n)}end
    local small={};for _,n in ipairs({16,18,20,22,24,26})do small[#small+1]={value=n,label=n.." px"}end
    W.Select(card,L("PER ROW"),per,math.floor(tonumber(cfg.perRow)or 0),12,34,207,function(v)cfg.perRow=v;apply()end,"pcd:perRow")
    W.Select(card,L("SIZE ON MORE ROWS"),small,tonumber(cfg.size2)or 20,235,34,207,function(v)cfg.size2=v;apply()end,"pcd:size2")
    W.Toggle(card,L("Highlight new timers"),cfg.highlight,12,96,430,function(v)cfg.highlight=v;apply()end,"pcd:highlight")
    W.Toggle(card,L("Tooltips"),cfg.tooltip,12,124,430,function(v)cfg.tooltip=v;apply()end,"pcd:tooltip")
    W.Label(card,L("With more icons than Per row, a member's icons go on more rows at the smaller size. A new timer gets a gold edge for 3 seconds. Tooltips show the spell and the time left when you point at an icon; with them on the icons take the mouse. The order of the icons is set per specialization on the Abilities page."),12,164,430,11,C.muted)
end
local function DrawPage(parent)
    local cfg=ns.PartyCooldownConfig()
    local function apply()ns.RefreshPartyCooldowns();kit.refresh()end
    local d=kit.state.drafts;d.pcd=d.pcd or{view="display"}
    kit.header(parent,L("Party cooldowns"),L("Important defensive, external, raid and burst cooldowns of every specialization, for each party member."))
    W.Segmented(parent,{{value="display",label=L("Display")},{value="anchors",label=L("Lists")},{value="extras",label=L("Extras")},{value="abilities",label=L("Abilities")},{value="profile",label=L("Profile")}},d.pcd.view,470,0,450,function(v)d.pcd.view=v;kit.refresh()end,"pcd-view")
    if d.pcd.view=="abilities"then return DrawAbilities(parent,d.pcd)end
    if d.pcd.view=="profile"and ns.DrawPartyProfile then return ns.DrawPartyProfile(parent,apply,d.pcd)end
    if d.pcd.view=="extras"and ns.DrawPartyExtras then return ns.DrawPartyExtras(parent,apply,d.pcd)end
    if d.pcd.view=="anchors"then return DrawAnchors(parent,apply,d.pcd)end
    local c1=W.Card(parent,0,56,298,566,L("Display"))
    W.Toggle(c1,L("Track party cooldowns"),cfg.enabled,12,34,274,function(v)cfg.enabled=v;apply()end,"pcd:enabled")
    W.Select(c1,L("SHOW"),{{value="list",label=L("As a list")},{value="frames",label=L("Beside party frames")}},cfg.mode,12,70,274,function(v)cfg.mode=v;apply()end,"pcd:mode")
    W.Select(c1,L("SIDE OF THE FRAME"),{{value="RIGHT",label=L("Right")},{value="LEFT",label=L("Left")},{value="TOP",label=L("Above")},{value="BOTTOM",label=L("Below")}},cfg.side,12,126,130,function(v)cfg.side=v;apply()end,"pcd:side")
    local sizes={};for _,s in ipairs({20,24,26,30,36})do sizes[#sizes+1]={value=s,label=s.." px"}end
    W.Select(c1,L("ICON SIZE"),sizes,tonumber(cfg.size)or 26,156,126,130,function(v)cfg.size=v;apply()end,"pcd:size")
    W.Toggle(c1,L("Include my own cooldowns"),cfg.self,12,186,274,function(v)cfg.self=v;apply()end,"pcd:self")
    W.Toggle(c1,L("In raids, track my group"),cfg.raidGroup,12,212,274,function(v)cfg.raidGroup=v;apply()end,"pcd:raid")
    W.Toggle(c1,L("Only in use"),cfg.hideReady,12,238,274,function(v)cfg.hideReady=v;apply()end,"pcd:hideReady")
    W.Toggle(c1,L("Names"),cfg.names,12,264,274,function(v)cfg.names=v;apply()end,"pcd:names")
    W.Toggle(c1,L("Share my cooldowns with the group"),cfg.share,12,290,274,function(v)cfg.share=v;if v then ns.SharePartyCooldowns(true)end;apply()end,"pcd:share")
    W.Toggle(c1,L("Also share my Cooldown Manager ones"),cfg.cdm,12,316,274,function(v)cfg.cdm=v;apply()end,"pcd:cdm")
    W.Toggle(c1,L("Auto 1 min+"),cfg.detect,12,342,274,function(v)cfg.detect=v;apply()end,"pcd:detect")
    W.Toggle(c1,L("Buff sensors"),cfg.sensors,12,368,274,function(v)cfg.sensors=v;apply()end,"pcd:sensors")
    W.Select(c1,nil,{{value="all",label=L("Everywhere")},{value="instances",label=L("Instances")},{value="dungeons",label=L("Dungeons")}},cfg.loadWhere or"all",12,392,130,function(v)cfg.loadWhere=v;apply()end,"pcd:loadWhere")
    W.Toggle(c1,L("Solo"),cfg.loadSolo~=false,156,394,130,function(v)cfg.loadSolo=v;apply()end,"pcd:loadSolo")
    W.Button(c1,cfg.unlocked and L("Lock")or L("Unlock and preview"),12,428,274,function()cfg.unlocked=not cfg.unlocked;apply()end,false,"pcd-unlock",{kind="outline",align="CENTER"})
    W.Button(c1,L("Reset timers"),12,466,130,function()ns.PartyCooldownReset();kit.notify(L("Group timers were reset; yours follow the game"))end,false,"pcd-reset",{kind="outline",align="CENTER"})
    W.Button(c1,L("Send mine now"),156,466,130,function()kit.done(ns.SharePartyCooldowns(true),L("Turn tracking on, join a group and leave combat first"),L("Your cooldowns were sent to the group"))end,false,"pcd-share",{align="CENTER"})
    W.Label(c1,L("Timers start when a member casts. The game can hide other players' casts in combat; then nothing is guessed. Mythic+ keys and raid encounters start everyone ready."),12,506,274,11,C.muted)
    local c2=W.Card(parent,310,56,610,566,L("Group"))
    if cfg.enabled then ns.PartyCooldownRoster()end
    local names=order;local y=34
    if #names==0 then W.Label(c2,cfg.enabled and L("Nobody to track yet. Join a party.")or L("Turn tracking on to see your group here."),12,y,580,12,C.muted)end
    for i,name in ipairs(names)do if i<=10 then
        local m=members[name];local row=W.Panel(c2,12,y,586,40,C.raised,C.clear,6)
        W.Dot(row,8,15,kit.classColor(m.class));W.Label(row,ns.PartyName(name),22,6,170,12,kit.classColor(m.class)):SetWordWrap(false)
        local source=m.me and L("You")or m.addon and L("Sent by their addon")or m.talented and L("Talents from inspect")or L("Base cooldowns from the game")
        W.Label(row,(m.spec and ns.Catalog.specs[m.spec]and L(ns.Catalog.specs[m.spec])or L("Specialization unknown")).." · "..source,22,22,170,10,C.muted):SetWordWrap(false)
        if m.seen or m.hidden or m.sensed then
            local t=W.Label(row,L("Casts")..": "..(m.seen or 0).." "..L("seen")..", "..(m.hidden or 0).." "..L("hidden")..", "..(m.sensed or 0).." "..L("by buff"),396,14,184,10,(m.hidden or 0)>0 and C.warning or C.muted);t:SetJustifyH("RIGHT")
        end
        local x=196
        for _,id in ipairs(ns.PartyCooldownList(m))do if x<=360 then
            W.Icon(row,id,x,6,28);x=x+30
        end end
        y=y+44
    end end
    local _,st=ns.PartyCooldownSensors()
    W.Label(c2,L("Buff sensors")..": "..(not cfg.sensors and L("off")or st.available==false and(L("not available")..", "..L(st.reason or""))or st.available and(#sensors..L(" watching"))or L("waiting for a group")),12,452,586,11,st.available==false and C.warning or C.soft)
    W.Label(c2,L("Members without this addon show the cooldowns of their specialization at the game's base length; talents that shorten them are not known. Members with the addon send the lengths they have. A ~ on a timer marks an estimate: a guessed start, a base or shortened length, or a timer the game hides."),12,476,586,11,C.muted)
end
ns.ExtraPages.partycds=DrawPage
