local _,ns=...
local W=ns.Widgets
local C=W.colors
local L=ns.L
local kit=ns.UIKit

local PREFIX="!PPD1:"
local SKIP={learned=true,talentSpells=true,unlocked=true,aliasMigrated=true,learnedVersion=true}
local MAX_TEXT,MAX_DEPTH,MAX_ITEMS=400000,12,50000

local function Write(v,out,depth)
    local kind=type(v)
    if kind=="table"then
        if depth>MAX_DEPTH then error("too deep")end
        out[#out+1]="t"
        local keys={};for k in pairs(v)do if type(k)=="string"or type(k)=="number"then keys[#keys+1]=k end end
        table.sort(keys,function(a,b)if type(a)~=type(b)then return type(a)=="number"end;return a<b end)
        for _,k in ipairs(keys)do local x=v[k];local t=type(x)
            if t=="table"or t=="string"or t=="number"or t=="boolean"then Write(k,out,depth+1);Write(x,out,depth+1)end
        end
        out[#out+1]="e"
    elseif kind=="string"then out[#out+1]="s"..#v..":"..v
    elseif kind=="number"then out[#out+1]="n"..string.format("%.17g",v)..";"
    elseif kind=="boolean"then out[#out+1]=v and"T"or"F"
    else error("unsupported "..kind)end
end
local function Read(text)
    local at,items=1,0
    local function value(depth)
        if depth>MAX_DEPTH then error("too deep")end
        items=items+1;if items>MAX_ITEMS then error("too big")end
        local c=text:sub(at,at);at=at+1
        if c=="t"then
            local t={}
            while true do
                if text:sub(at,at)=="e"then at=at+1;return t end
                if at>#text then error("cut off")end
                local k=value(depth+1)
                if type(k)~="string"and type(k)~="number"then error("bad key")end
                t[k]=value(depth+1)
            end
        elseif c=="s"then
            local colon=text:find(":",at,true);if not colon then error("cut off")end
            local len=tonumber(text:sub(at,colon-1));if not len or len<0 or colon+len>#text then error("cut off")end
            local s=text:sub(colon+1,colon+len);at=colon+len+1;return s
        elseif c=="n"then
            local semi=text:find(";",at,true);if not semi then error("cut off")end
            local n=tonumber(text:sub(at,semi-1));if not n or n~=n then error("bad number")end
            at=semi+1;return n
        elseif c=="T"then return true
        elseif c=="F"then return false end
        error("bad data")
    end
    local v=value(0)
    if at<=#text then error("extra data")end
    return v
end

local CHARS="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local INDEX={};for i=1,64 do INDEX[CHARS:sub(i,i)]=i-1 end
local function Encode64(data)
    local out={}
    for i=1,#data,3 do
        local a,b,c=data:byte(i,i+2);local n=a*65536+(b or 0)*256+(c or 0)
        local d1,d2,d3,d4=math.floor(n/262144),math.floor(n/4096)%64,math.floor(n/64)%64,n%64
        out[#out+1]=CHARS:sub(d1+1,d1+1)..CHARS:sub(d2+1,d2+1)..(b and CHARS:sub(d3+1,d3+1)or"=")..(c and CHARS:sub(d4+1,d4+1)or"=")
    end
    return table.concat(out)
end
local function Decode64(text)
    text=text:gsub("[^%w%+/=]","")
    if #text%4~=0 then error("cut off")end
    local out={}
    for i=1,#text,4 do
        local q={text:byte(i,i+3)};local n,pad=0,0
        for k=1,4 do local ch=string.char(q[k])
            if ch=="="then pad=pad+1;n=n*64 else local v=INDEX[ch];if not v then error("bad text")end;n=n*64+v end
        end
        local a,b,c=math.floor(n/65536),math.floor(n/256)%256,n%256
        out[#out+1]=string.char(a)..(pad<2 and string.char(b)or"")..(pad<1 and string.char(c)or"")
    end
    return table.concat(out)
end
ns.PartyProfileBase64={encode=Encode64,decode=Decode64}

function ns.PartyProfileExport()
    local cfg=ns.PartyCooldownConfig();if ns.PartyExtrasConfig then ns.PartyExtrasConfig()end
    local copy={}
    for k,v in pairs(cfg)do if not SKIP[k]then copy[k]=v end end
    local out={};Write({v=1,version=tostring(ns.version or""),settings=copy},out,0)
    return PREFIX..Encode64(table.concat(out))
end
function ns.PartyProfileImport(text)
    if type(text)~="string"then return false,L("Paste a profile string first")end
    text=text:gsub("^%s+",""):gsub("%s+$","")
    if text==""then return false,L("Paste a profile string first")end
    if #text>MAX_TEXT then return false,L("This profile string is too long")end
    if text:sub(1,#PREFIX)~=PREFIX then return false,L("This is not a party cooldowns profile string")end
    local ok,data=pcall(function()return Read(Decode64(text:sub(#PREFIX+1)))end)
    if not ok or type(data)~="table"or type(data.settings)~="table"then return false,L("This profile string is damaged")end
    local cfg=ns.PartyCooldownConfig()
    local n=0
    for k,v in pairs(data.settings)do
        if type(k)=="string"and not SKIP[k]and(cfg[k]==nil or type(cfg[k])==type(v))then cfg[k]=v;n=n+1 end
    end
    if n==0 then return false,L("This profile string is damaged")end
    ns.PartyCooldownConfig();if ns.PartyExtrasConfig then ns.PartyExtrasConfig()end
    if ns.RefreshPartyCooldowns then ns.RefreshPartyCooldowns()end
    if ns.RefreshPartyExtras then ns.RefreshPartyExtras()end
    return true
end

function ns.DrawPartyProfile(parent,apply,d)
    local left=W.Card(parent,0,56,454,566,L("Share my settings"))
    W.Label(left,L("Every setting of the party cooldowns, lists, look and extras in one string. Press the box, then Ctrl+A and Ctrl+C, and share it."),12,34,430,11,C.muted)
    local out=W.Input(left,d.exported or"",12,80,430,"pcd-profile:export",true)
    W.Button(left,L("Make the string"),12,276,430,function()d.exported=ns.PartyProfileExport();kit.refresh()
        local box=ns.UIControls["pcd-profile:export"];if box then box:SetFocus();box:HighlightText()end end,false,"pcd-profile:make",{kind="primary",align="CENTER"})
    if out and out.SetScript then out:SetScript("OnEditFocusGained",function(self)self:HighlightText()end)end
    local right=W.Card(parent,466,56,454,566,L("Use someone's settings"))
    W.Label(right,L("Paste a profile string and press Import. Your settings are replaced; your learned cooldown lengths stay."),12,34,430,11,C.muted)
    local input=W.Input(right,d.importText or"",12,80,430,"pcd-profile:import",true)
    W.OnText(input,function(self)d.importText=self:GetText()end)
    W.Button(right,L("Import"),12,276,430,function()
        local box=ns.UIControls["pcd-profile:import"];local text=box and box:GetText()or d.importText
        local ok,err=ns.PartyProfileImport(text);if ok then d.importText=""end
        kit.done(ok,err,L("Profile imported"))
    end,false,"pcd-profile:importButton",{kind="primary",align="CENTER"})
end
